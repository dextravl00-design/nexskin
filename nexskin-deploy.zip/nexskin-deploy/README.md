# NexSkin 🌿
Skin analysis app for Nigerian users. Built with Expo + React Native Web.

## Features
- 📸 Skin scan with camera analysis
- 📊 Skin score tracking & trend chart
- 📅 Daily skin journal & weekly ratings
- 🛁 Morning & night routine builder
- 🛍️ Nigerian product recommendations (Jumia/Konga)
- 👩🏾‍⚕️ Virtual dermatologist booking
- 🌙 Dark mode support

---

## 🚀 Deploy to Vercel (Web App)

### Option A — GitHub + Vercel (recommended)

1. Push this folder to a new GitHub repo:
   ```bash
   git init
   git add .
   git commit -m "Initial NexSkin commit"
   git remote add origin https://github.com/YOUR_USERNAME/nexskin.git
   git push -u origin main
   ```

2. Go to [vercel.com](https://vercel.com) → **Add New Project** → Import your GitHub repo

3. Vercel will auto-detect the settings from `vercel.json`. Just click **Deploy**.

4. Your app will be live at `https://nexskin.vercel.app` (or your custom domain)

### Option B — Vercel CLI (fastest)

```bash
npm install -g vercel
npm install
vercel --prod
```

---

## 📱 Run on Your Phone (Expo Go)

1. Install [Expo Go](https://expo.dev/client) on your phone
2. Run:
   ```bash
   npm install
   npx expo start
   ```
3. Scan the QR code with your phone camera (iOS) or Expo Go (Android)

---

## 💻 Run Locally

```bash
npm install
npm run web        # Opens in browser
npm run android    # Opens on Android (needs Android Studio)
npm run ios        # Opens on iOS (needs Xcode, Mac only)
```

---

## 📦 Build for Production

```bash
# Web (for Vercel/hosting)
npm run build:web

# Mobile (needs EAS CLI — for app stores)
npx eas build --platform android
npx eas build --platform ios
```

---

## 🗂️ Project Structure

```
nexskin/
├── app/
│   ├── (tabs)/          # Tab screens (Home, Tracking, Routine, Products, Consult, Settings)
│   ├── scan.tsx          # Camera scan screen
│   ├── scan-results.tsx  # Scan analysis results
│   ├── history.tsx       # Scan history + comparison + trend chart
│   ├── routine-editor.tsx # Build morning/night routines
│   ├── product-detail.tsx # Nigerian product details
│   ├── consult-booking.tsx # Book dermatologist
│   └── consult-confirmation.tsx
├── lib/
│   ├── skin-context.tsx  # Global state (AsyncStorage)
│   ├── theme-provider.tsx # Dark/light mode
│   ├── types.ts          # TypeScript types
│   └── storage.ts        # AsyncStorage helpers
├── hooks/
│   └── use-colors.ts     # Theme colours hook
├── components/
│   └── screen-container.tsx
├── vercel.json           # Vercel deployment config
└── app.config.ts         # Expo config
```

---

## 🔑 Environment Variables

None required for basic use. The app runs fully client-side with AsyncStorage.

If you want smart weekly insights (weekly tracking screen), the Anthropic API key is called
directly from the client. For production, add it as a Vercel env variable:

```
EXPO_PUBLIC_ANTHROPIC_KEY=your_key_here
```

Then in `app/(tabs)/tracking.tsx`, update the fetch headers:
```js
"x-api-key": process.env.EXPO_PUBLIC_ANTHROPIC_KEY,
```
