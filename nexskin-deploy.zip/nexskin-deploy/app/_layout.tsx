import "@/global.css";
import { Stack } from "expo-router";
import { StatusBar } from "expo-status-bar";
import { GestureHandlerRootView } from "react-native-gesture-handler";
import { SafeAreaProvider } from "react-native-safe-area-context";
import { ThemeProvider } from "@/lib/theme-provider";
import { SkinProvider } from "@/lib/skin-context";
import { VendorProvider } from "@/lib/vendor-context";

export const unstable_settings = { anchor: "(tabs)" };

export default function RootLayout() {
  return (
    <GestureHandlerRootView style={{ flex: 1 }}>
      <SafeAreaProvider>
        <ThemeProvider>
          <SkinProvider>
            <VendorProvider>
              <Stack screenOptions={{ headerShown: false }}>
                <Stack.Screen name="(tabs)" />
                <Stack.Screen name="scan" />
                <Stack.Screen name="scan-results" />
                <Stack.Screen name="history" />
                <Stack.Screen name="routine-editor" />
                <Stack.Screen name="routine" />
                <Stack.Screen name="tracking" />
                <Stack.Screen name="product-detail" />
                <Stack.Screen name="consult-booking" />
                <Stack.Screen name="consult-confirmation" />
                <Stack.Screen name="vendor/onboarding" />
                <Stack.Screen name="vendor/dashboard" />
                <Stack.Screen name="vendor/add-product" />
                <Stack.Screen name="vendor/orders" />
                <Stack.Screen name="vendor/analytics" />
                <Stack.Screen name="vendor/store" />
              </Stack>
              <StatusBar style="auto" />
            </VendorProvider>
          </SkinProvider>
        </ThemeProvider>
      </SafeAreaProvider>
    </GestureHandlerRootView>
  );
}
