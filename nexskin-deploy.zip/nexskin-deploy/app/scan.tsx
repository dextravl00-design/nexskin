import { useState, useRef } from "react";
import { ScrollView, Text, View, TouchableOpacity, Image, ActivityIndicator, Platform, Alert } from "react-native";
import { useRouter } from "expo-router";
import { ScreenContainer } from "@/components/screen-container";
import { useColors } from "@/hooks/use-colors";
import { useSkinContext } from "@/lib/skin-context";
import { SkinScan, SkinMetrics } from "@/lib/types";
import { MaterialIcons } from "@expo/vector-icons";

// Lazy-load expo-camera only on native to avoid web errors
let CameraView: any = null;
let useCameraPermissions: any = null;

if (Platform.OS !== "web") {
  try {
    const Camera = require("expo-camera");
    CameraView = Camera.CameraView;
    useCameraPermissions = Camera.useCameraPermissions;
  } catch (e) {}
}

// Hook wrapper that works even when expo-camera is unavailable
function useCameraPerms() {
  if (useCameraPermissions) {
    // eslint-disable-next-line react-hooks/rules-of-hooks
    return useCameraPermissions();
  }
  return [null, async () => ({ granted: false })];
}

export default function ScanScreen() {
  const router = useRouter();
  const colors = useColors();
  const { addScan } = useSkinContext();
  const [isLoading, setIsLoading] = useState(false);
  const [capturedImageUri, setCapturedImageUri] = useState<string | null>(null);
  const [cameraReady, setCameraReady] = useState(false);
  const [showCamera, setShowCamera] = useState(false);
  const cameraRef = useRef<any>(null);
  const [permission, requestPermission] = useCameraPerms();

  const handleOpenCamera = async () => {
    if (Platform.OS === "web") {
      // Web fallback: skip real camera
      setIsLoading(true);
      await new Promise((r) => setTimeout(r, 800));
      setCapturedImageUri("https://via.placeholder.com/400x400/f0e6ff/9b59b6?text=Face+Scan");
      setIsLoading(false);
      return;
    }

    if (!CameraView) {
      Alert.alert("Camera not available", "Please run: npx expo install expo-camera");
      return;
    }

    if (!permission?.granted) {
      const result = await requestPermission();
      if (!result.granted) {
        Alert.alert(
          "Camera Permission Required",
          "NexSkin needs camera access to scan your skin. Please allow camera access in Settings.",
          [{ text: "OK" }]
        );
        return;
      }
    }
    setShowCamera(true);
  };

  const handleCapture = async () => {
    if (!cameraRef.current || !cameraReady) return;
    try {
      setIsLoading(true);
      const photo = await cameraRef.current.takePictureAsync({ quality: 0.8 });
      setCapturedImageUri(photo.uri);
      setShowCamera(false);
    } catch {
      Alert.alert("Error", "Failed to capture photo. Please try again.");
    } finally {
      setIsLoading(false);
    }
  };

  const handleAnalyzePhoto = async () => {
    if (!capturedImageUri) return;
    setIsLoading(true);
    await new Promise((r) => setTimeout(r, 2500));

    const mockMetrics: SkinMetrics = {
      hydration: Math.floor(Math.random() * 40) + 50,
      poreSize: Math.floor(Math.random() * 50) + 30,
      darkSpots: Math.floor(Math.random() * 10),
      redness: Math.floor(Math.random() * 40) + 20,
      texture: Math.floor(Math.random() * 40) + 50,
    };

    const mockScan: SkinScan = {
      id: Date.now().toString(),
      timestamp: Date.now(),
      imageUri: capturedImageUri,
      skinScore: Math.floor(
        (mockMetrics.hydration + (100 - mockMetrics.poreSize) + (100 - mockMetrics.darkSpots * 5) + (100 - mockMetrics.redness) + mockMetrics.texture) / 5
      ),
      skinType: "normal",
      metrics: mockMetrics,
      recommendations: [
        "Drink at least 8 glasses of water daily",
        "Use a gentle exfoliant 2x per week",
        "Apply SPF 50+ daily — essential in Nigerian sun",
        "Try a niacinamide serum for even skin tone",
        "Use a hydrating toner after cleansing",
      ],
      conditionSummary: "Your skin shows good baseline health. Focus on hydration and sun protection for optimal results in tropical climates.",
    };

    await addScan(mockScan);
    setIsLoading(false);
    router.push("../scan-results");
  };

  // Live camera view
  if (showCamera && CameraView) {
    return (
      <View style={{ flex: 1, backgroundColor: "#000" }}>
        <CameraView
          ref={cameraRef}
          style={{ flex: 1 }}
          facing="front"
          onCameraReady={() => setCameraReady(true)}
        >
          <View style={{ flex: 1, alignItems: "center", justifyContent: "center" }}>
            {/* Top bar */}
            <View style={{ position: "absolute", top: 0, left: 0, right: 0, flexDirection: "row", justifyContent: "space-between", alignItems: "center", paddingHorizontal: 16, paddingTop: 52, paddingBottom: 16 }}>
              <TouchableOpacity onPress={() => setShowCamera(false)} style={{ backgroundColor: "rgba(0,0,0,0.5)", borderRadius: 50, padding: 8 }}>
                <MaterialIcons name="close" size={24} color="white" />
              </TouchableOpacity>
              <Text style={{ color: "white", fontWeight: "600", fontSize: 14 }}>Centre your face</Text>
              <View style={{ width: 40 }} />
            </View>

            {/* Oval face guide */}
            <View style={{ width: 240, height: 300, borderRadius: 120, borderWidth: 3, borderColor: "rgba(255,255,255,0.85)", borderStyle: "dashed" }} />

            {/* Capture button */}
            <View style={{ position: "absolute", bottom: 0, left: 0, right: 0, alignItems: "center", paddingBottom: 48 }}>
              <TouchableOpacity
                onPress={handleCapture}
                disabled={isLoading || !cameraReady}
                style={{ width: 80, height: 80, borderRadius: 40, backgroundColor: "white", borderWidth: 4, borderColor: "rgba(255,255,255,0.5)", alignItems: "center", justifyContent: "center", opacity: !cameraReady ? 0.5 : 1 }}
              >
                {isLoading ? <ActivityIndicator size="small" color="#000" /> : <MaterialIcons name="camera-alt" size={36} color="#000" />}
              </TouchableOpacity>
              {!cameraReady && <Text style={{ color: "white", fontSize: 12, marginTop: 8 }}>Initialising camera...</Text>}
            </View>
          </View>
        </CameraView>
      </View>
    );
  }

  return (
    <ScreenContainer className="p-4">
      <ScrollView contentContainerStyle={{ flexGrow: 1 }} showsVerticalScrollIndicator={false}>
        <View className="gap-6 pb-8">
          {/* Header */}
          <View className="flex-row justify-between items-center mt-2">
            <Text className="text-3xl font-bold text-foreground">Skin Scan</Text>
            <TouchableOpacity onPress={() => router.back()}>
              <MaterialIcons name="close" size={28} color={colors.foreground} />
            </TouchableOpacity>
          </View>

          {/* Tips */}
          <View className="bg-primary/10 rounded-2xl p-4 border border-primary/20">
            <Text className="text-sm font-medium text-foreground mb-2">Tips for Best Results</Text>
            <Text className="text-xs text-muted leading-relaxed">
              {"• Find good lighting (natural light is best)\n• Face the camera directly\n• Centre your face in the oval guide\n• Remove glasses or sunglasses\n• Cleanse your face before scanning"}
            </Text>
          </View>

          {/* Preview */}
          <View className="bg-surface rounded-2xl overflow-hidden border border-border aspect-square items-center justify-center">
            {capturedImageUri ? (
              <Image source={{ uri: capturedImageUri }} style={{ width: "100%", height: "100%" }} resizeMode="cover" />
            ) : isLoading ? (
              <View className="items-center gap-3">
                <ActivityIndicator size="large" color={colors.primary} />
                <Text className="text-sm text-muted">Opening camera...</Text>
              </View>
            ) : (
              <View className="items-center gap-3">
                <View style={{ width: 120, height: 150, borderRadius: 60, borderWidth: 3, borderColor: colors.muted, borderStyle: "dashed", alignItems: "center", justifyContent: "center" }}>
                  <MaterialIcons name="face" size={48} color={colors.muted} />
                </View>
                <Text className="text-sm text-muted">Tap below to open camera</Text>
              </View>
            )}
          </View>

          {/* Buttons */}
          <View className="gap-3">
            {!capturedImageUri ? (
              <TouchableOpacity onPress={handleOpenCamera} disabled={isLoading} className="bg-primary rounded-xl py-4 items-center" style={{ opacity: isLoading ? 0.6 : 1 }}>
                <View className="flex-row items-center gap-2">
                  <MaterialIcons name="camera-alt" size={20} color={colors.background} />
                  <Text className="text-base font-semibold text-background">
                    {isLoading ? "Opening Camera..." : "Open Camera"}
                  </Text>
                </View>
              </TouchableOpacity>
            ) : (
              <>
                <TouchableOpacity onPress={handleAnalyzePhoto} disabled={isLoading} className="bg-primary rounded-xl py-4 items-center" style={{ opacity: isLoading ? 0.6 : 1 }}>
                  {isLoading ? (
                    <View className="flex-row items-center gap-2">
                      <ActivityIndicator size="small" color={colors.background} />
                      <Text className="text-base font-semibold text-background">Analysing Skin...</Text>
                    </View>
                  ) : (
                    <View className="flex-row items-center gap-2">
                      <MaterialIcons name="biotech" size={20} color={colors.background} />
                      <Text className="text-base font-semibold text-background">Analyse Skin</Text>
                    </View>
                  )}
                </TouchableOpacity>
                <TouchableOpacity onPress={() => { setCapturedImageUri(null); setShowCamera(false); }} disabled={isLoading} className="bg-surface border border-border rounded-xl py-4 items-center" style={{ opacity: isLoading ? 0.6 : 1 }}>
                  <Text className="text-base font-semibold text-foreground">Retake Photo</Text>
                </TouchableOpacity>
              </>
            )}
          </View>
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}
