import { View, Text, TouchableOpacity, ScrollView } from "react-native";
import { useRouter } from "expo-router";
import { ScreenContainer } from "@/components/screen-container";
import { useColors } from "@/hooks/use-colors";
import { MaterialIcons } from "@expo/vector-icons";

export default function ConsultConfirmationScreen() {
  const router = useRouter();
  const colors = useColors();

  return (
    <ScreenContainer className="p-4">
      <ScrollView contentContainerStyle={{ flexGrow: 1 }} showsVerticalScrollIndicator={false}>
        <View className="flex-1 gap-6 pb-8">
          {/* Header */}
          <View className="flex-row justify-between items-center mt-2">
            <Text className="text-2xl font-bold text-foreground">Booking Confirmed</Text>
            <TouchableOpacity onPress={() => router.push("/(tabs)")}>
              <MaterialIcons name="close" size={28} color={colors.foreground} />
            </TouchableOpacity>
          </View>

          {/* Success */}
          <View className="rounded-3xl p-8 border items-center gap-4"
            style={{ backgroundColor: `${colors.success}12`, borderColor: `${colors.success}40` }}>
            <View className="w-20 h-20 rounded-full items-center justify-center"
              style={{ backgroundColor: `${colors.success}25` }}>
              <MaterialIcons name="check-circle" size={48} color={colors.success} />
            </View>
            <Text className="text-xl font-bold text-foreground text-center">
              Your consultation is booked!
            </Text>
            <Text className="text-sm text-muted text-center leading-relaxed">
              A confirmation will be sent to you. Your dermatologist will connect with you at the scheduled time.
            </Text>
          </View>

          {/* Details */}
          <View className="rounded-2xl p-4 border gap-4"
            style={{ backgroundColor: colors.surface, borderColor: colors.border }}>
            {[
              { icon: "person", label: "Doctor", value: "Dr. Adaeze Okonkwo" },
              { icon: "calendar-today", label: "Date & Time", value: "Wed, Apr 15 · 10:00 AM" },
              { icon: "video-call", label: "Type", value: "Video Consultation" },
              { icon: "confirmation-number", label: "Confirmation ID", value: "NEXSKIN-20260415-001" },
            ].map((item) => (
              <View key={item.label} className="flex-row items-center gap-3">
                <MaterialIcons name={item.icon as any} size={20} color={colors.primary} />
                <View className="flex-1">
                  <Text className="text-xs text-muted">{item.label}</Text>
                  <Text className="text-sm font-medium text-foreground">{item.value}</Text>
                </View>
              </View>
            ))}
          </View>

          {/* Prep tips */}
          <View className="rounded-2xl p-4 border"
            style={{ backgroundColor: colors.surface, borderColor: colors.border }}>
            <Text className="text-sm font-semibold text-foreground mb-3">How to Prepare</Text>
            {[
              "Cleanse your face 30 minutes before the call",
              "Have good lighting — sit near a window",
              "Note any recent skin changes or reactions",
              "List products you currently use",
            ].map((tip, i) => (
              <View key={i} className="flex-row gap-3 mb-2">
                <Text className="text-xs font-bold" style={{ color: colors.primary }}>{i + 1}.</Text>
                <Text className="text-xs text-muted flex-1 leading-relaxed">{tip}</Text>
              </View>
            ))}
          </View>

          {/* Actions */}
          <View className="gap-3">
            <TouchableOpacity className="rounded-xl py-4 items-center"
              style={{ backgroundColor: colors.primary }}>
              <View className="flex-row items-center gap-2">
                <MaterialIcons name="video-call" size={20} color={colors.surface} />
                <Text className="text-base font-semibold" style={{ color: colors.surface }}>
                  Join Video Call
                </Text>
              </View>
            </TouchableOpacity>
            <TouchableOpacity onPress={() => router.push("/(tabs)")}
              className="rounded-xl py-4 items-center border"
              style={{ backgroundColor: colors.surface, borderColor: colors.border }}>
              <Text className="text-base font-semibold text-foreground">Back to Home</Text>
            </TouchableOpacity>
          </View>
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}
