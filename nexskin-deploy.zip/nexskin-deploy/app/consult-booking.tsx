import { ScrollView, Text, View, TouchableOpacity, FlatList } from "react-native";
import { useRouter } from "expo-router";
import { useState } from "react";
import { ScreenContainer } from "@/components/screen-container";
import { useColors } from "@/hooks/use-colors";
import { MaterialIcons } from "@expo/vector-icons";

const DERMATOLOGISTS = [
  {
    id: "1", name: "Dr. Adaeze Okonkwo", specialty: "Acne & Hyperpigmentation",
    rating: 4.9, reviews: 312, experience: "11 years", price: 15000,
    availability: ["2026-04-15T10:00", "2026-04-15T14:00", "2026-04-16T09:00"],
    image: "👩🏾‍⚕️",
  },
  {
    id: "2", name: "Dr. Emeka Nwosu", specialty: "Anti-Aging & Skin Rejuvenation",
    rating: 4.8, reviews: 201, experience: "15 years", price: 18000,
    availability: ["2026-04-15T11:00", "2026-04-16T10:00", "2026-04-17T14:00"],
    image: "👨🏾‍⚕️",
  },
  {
    id: "3", name: "Dr. Funmi Adeyemi", specialty: "Sensitive Skin & Eczema",
    rating: 4.7, reviews: 178, experience: "9 years", price: 12000,
    availability: ["2026-04-16T09:00", "2026-04-16T15:00", "2026-04-17T11:00"],
    image: "👩🏿‍⚕️",
  },
];

export default function ConsultBookingScreen() {
  const router = useRouter();
  const colors = useColors();
  const [selectedDoctor, setSelectedDoctor] = useState<string | null>(null);
  const [selectedSlot, setSelectedSlot] = useState<string | null>(null);

  const doctor = DERMATOLOGISTS.find((d) => d.id === selectedDoctor);

  const formatSlot = (iso: string) =>
    new Date(iso).toLocaleString("en-NG", {
      weekday: "short", month: "short", day: "numeric", hour: "2-digit", minute: "2-digit",
    });

  const handleConfirm = () => {
    if (!selectedDoctor || !selectedSlot) return;
    router.push("../consult-confirmation");
  };

  return (
    <ScreenContainer className="p-4">
      <ScrollView contentContainerStyle={{ flexGrow: 1 }} showsVerticalScrollIndicator={false}>
        <View className="gap-6 pb-8">
          {/* Header */}
          <View className="flex-row justify-between items-center mt-2">
            <View>
              <Text className="text-3xl font-bold text-foreground">Book Consult</Text>
              <Text className="text-sm text-muted mt-1">Online consultation via video</Text>
            </View>
            <TouchableOpacity onPress={() => router.back()}>
              <MaterialIcons name="close" size={28} color={colors.foreground} />
            </TouchableOpacity>
          </View>

          {/* Doctors */}
          <View>
            <Text className="text-base font-semibold text-foreground mb-3">Choose a Dermatologist</Text>
            {DERMATOLOGISTS.map((doc) => (
              <TouchableOpacity
                key={doc.id}
                onPress={() => { setSelectedDoctor(doc.id); setSelectedSlot(null); }}
                className="rounded-2xl p-4 border mb-3"
                style={{
                  backgroundColor: selectedDoctor === doc.id ? `${colors.primary}12` : colors.surface,
                  borderColor: selectedDoctor === doc.id ? colors.primary : colors.border,
                }}>
                <View className="flex-row gap-4 items-start">
                  <Text style={{ fontSize: 38 }}>{doc.image}</Text>
                  <View className="flex-1">
                    <View className="flex-row justify-between items-start">
                      <Text className="text-base font-semibold text-foreground">{doc.name}</Text>
                      {selectedDoctor === doc.id && (
                        <MaterialIcons name="check-circle" size={20} color={colors.primary} />
                      )}
                    </View>
                    <Text className="text-xs mt-0.5" style={{ color: colors.primary }}>{doc.specialty}</Text>
                    <View className="flex-row items-center gap-3 mt-2">
                      <View className="flex-row items-center gap-1">
                        <MaterialIcons name="star" size={13} color={colors.warning} />
                        <Text className="text-xs text-foreground font-medium">{doc.rating}</Text>
                        <Text className="text-xs text-muted">({doc.reviews})</Text>
                      </View>
                      <Text className="text-xs text-muted">·</Text>
                      <Text className="text-xs text-muted">{doc.experience}</Text>
                    </View>
                    <Text className="text-base font-bold mt-2" style={{ color: colors.primary }}>
                      ₦{doc.price.toLocaleString("en-NG")} / session
                    </Text>
                  </View>
                </View>
              </TouchableOpacity>
            ))}
          </View>

          {/* Time slots */}
          {doctor && (
            <View>
              <Text className="text-base font-semibold text-foreground mb-3">
                Available Slots — {doctor.name.split(" ")[1]}
              </Text>
              <View className="flex-row flex-wrap gap-2">
                {doctor.availability.map((slot) => (
                  <TouchableOpacity
                    key={slot}
                    onPress={() => setSelectedSlot(slot)}
                    className="rounded-xl px-4 py-3 border"
                    style={{
                      backgroundColor: selectedSlot === slot ? colors.primary : colors.surface,
                      borderColor: selectedSlot === slot ? colors.primary : colors.border,
                    }}>
                    <Text className="text-xs font-medium"
                      style={{ color: selectedSlot === slot ? colors.surface : colors.foreground }}>
                      {formatSlot(slot)}
                    </Text>
                  </TouchableOpacity>
                ))}
              </View>
            </View>
          )}

          {/* Confirm */}
          {selectedDoctor && selectedSlot && (
            <View className="rounded-2xl p-4 border gap-3"
              style={{ backgroundColor: `${colors.primary}10`, borderColor: `${colors.primary}30` }}>
              <Text className="text-sm font-semibold text-foreground">Booking Summary</Text>
              <Text className="text-sm text-muted">{doctor?.name}</Text>
              <Text className="text-sm text-muted">{formatSlot(selectedSlot)}</Text>
              <Text className="text-base font-bold" style={{ color: colors.primary }}>
                ₦{doctor?.price.toLocaleString("en-NG")}
              </Text>
            </View>
          )}

          <TouchableOpacity
            onPress={handleConfirm}
            disabled={!selectedDoctor || !selectedSlot}
            className="rounded-xl py-4 items-center"
            style={{
              backgroundColor: colors.primary,
              opacity: !selectedDoctor || !selectedSlot ? 0.4 : 1,
            }}>
            <Text className="text-base font-semibold" style={{ color: colors.surface }}>
              Confirm Booking
            </Text>
          </TouchableOpacity>
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}
