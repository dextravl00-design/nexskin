import { ScrollView, Text, View, TouchableOpacity } from "react-native";
import { useRouter } from "expo-router";
import { useState } from "react";
import { ScreenContainer } from "@/components/screen-container";
import { useColors } from "@/hooks/use-colors";
import { useSkinContext } from "@/lib/skin-context";
import { MaterialIcons } from "@expo/vector-icons";

export default function RoutineScreen() {
  const router = useRouter();
  const colors = useColors();
  const { routines } = useSkinContext();
  const [selectedType, setSelectedType] = useState<"morning" | "night">("morning");

  const filteredRoutines = routines.filter((r) => r.type === selectedType);

  const RoutineCard = ({ routine }: any) => {
    const totalTime = routine.products.reduce((sum: number, p: any) => sum + p.estimatedTime, 0);
    return (
      <View className="bg-surface rounded-2xl p-4 border border-border mb-3">
        <View className="flex-row justify-between items-start mb-3">
          <View className="flex-1">
            <Text className="text-sm font-medium text-foreground">
              {selectedType === "morning" ? "Morning" : "Night"} Routine
            </Text>
            <Text className="text-xs text-muted mt-1">
              {routine.products.length} product{routine.products.length !== 1 ? "s" : ""} • {totalTime} min
            </Text>
          </View>
          <TouchableOpacity onPress={() => router.push(`../routine-editor?id=${routine.id}`)}>
            <MaterialIcons name="edit" size={20} color={colors.primary} />
          </TouchableOpacity>
        </View>

        {/* Product List */}
        <View className="gap-2">
          {routine.products.slice(0, 3).map((product: any, index: number) => (
            <View key={index} className="flex-row items-center gap-2">
              <View
                className="w-2 h-2 rounded-full"
                style={{ backgroundColor: colors.primary }}
              />
              <Text className="text-xs text-muted flex-1">{product.name}</Text>
              <Text className="text-xs text-muted">{product.estimatedTime}m</Text>
            </View>
          ))}
          {routine.products.length > 3 && (
            <Text className="text-xs text-primary mt-1">
              +{routine.products.length - 3} more
            </Text>
          )}
        </View>

        {/* Reminder */}
        {routine.reminderEnabled && routine.reminderTime && (
          <View className="flex-row items-center gap-2 mt-3 pt-3 border-t border-border">
            <MaterialIcons name="notifications-active" size={14} color={colors.primary} />
            <Text className="text-xs text-primary">Reminder at {routine.reminderTime}</Text>
          </View>
        )}
      </View>
    );
  };

  return (
    <ScreenContainer className="p-4">
      <ScrollView contentContainerStyle={{ flexGrow: 1 }} showsVerticalScrollIndicator={false}>
        <View className="gap-4 pb-8">
          {/* Header */}
          <View className="mt-2">
            <Text className="text-3xl font-bold text-foreground">My Routines</Text>
            <Text className="text-sm text-muted mt-1">Build and manage your skincare</Text>
          </View>

          {/* Type Selector */}
          <View className="flex-row gap-3">
            <TouchableOpacity
              onPress={() => setSelectedType("morning")}
              className={`flex-1 rounded-xl py-3 items-center border ${
                selectedType === "morning"
                  ? "bg-primary border-primary"
                  : "bg-surface border-border"
              }`}
            >
              <Text
                className="text-sm font-semibold"
                style={{
                  color: selectedType === "morning" ? colors.background : colors.foreground,
                }}
              >
                Morning
              </Text>
            </TouchableOpacity>
            <TouchableOpacity
              onPress={() => setSelectedType("night")}
              className={`flex-1 rounded-xl py-3 items-center border ${
                selectedType === "night"
                  ? "bg-primary border-primary"
                  : "bg-surface border-border"
              }`}
            >
              <Text
                className="text-sm font-semibold"
                style={{
                  color: selectedType === "night" ? colors.background : colors.foreground,
                }}
              >
                Night
              </Text>
            </TouchableOpacity>
          </View>

          {/* Routines List */}
          {filteredRoutines.length > 0 ? (
            <View>
              {filteredRoutines.map((routine) => (
                <RoutineCard key={routine.id} routine={routine} />
              ))}
            </View>
          ) : (
            <View className="bg-surface rounded-2xl p-6 border border-border items-center gap-3">
              <MaterialIcons name="playlist-add" size={40} color={colors.muted} />
              <Text className="text-base font-medium text-foreground">
                No {selectedType} routine yet
              </Text>
              <Text className="text-sm text-muted text-center">
                Create your first {selectedType} routine to get started
              </Text>
            </View>
          )}

          {/* Create Routine Button */}
          <TouchableOpacity
            onPress={() => router.push(`../routine-editor?type=${selectedType}`)}
            className="bg-primary rounded-xl py-4 items-center mt-4"
          >
            <View className="flex-row items-center gap-2">
              <MaterialIcons name="add" size={20} color={colors.background} />
              <Text className="text-base font-semibold text-background">
                Create {selectedType === "morning" ? "Morning" : "Night"} Routine
              </Text>
            </View>
          </TouchableOpacity>
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}
