import { ScrollView, Text, View, TouchableOpacity, TextInput, ActivityIndicator, Alert } from "react-native";
import { useRouter } from "expo-router";
import { useState } from "react";
import { ScreenContainer } from "@/components/screen-container";
import { useColors } from "@/hooks/use-colors";
import { useSkinContext } from "@/lib/skin-context";
import { MaterialIcons } from "@expo/vector-icons";

const RATING_LABELS = ["", "Very Bad", "Bad", "Okay", "Good", "Excellent"];
const RATING_EMOJIS = ["", "😟", "😕", "😐", "🙂", "😊"];

export default function TrackingScreen() {
  const router = useRouter();
  const colors = useColors();
  const { weeklyEntries, addWeeklyEntry, scans } = useSkinContext();

  const today = new Date().toISOString().split("T")[0];
  const todayEntry = weeklyEntries.find((e) => e.date === today);

  const [todayRating, setTodayRating] = useState(todayEntry?.skinRating || 0);
  const [notes, setNotes] = useState(todayEntry?.notes || "");
  const [isSaving, setIsSaving] = useState(false);
  const [isGeneratingInsights, setIsGeneratingInsights] = useState(false);
  const [aiInsights, setAiInsights] = useState<string | null>(null);

  // Get last 7 days
  const last7Days = Array.from({ length: 7 }, (_, i) => {
    const d = new Date();
    d.setDate(d.getDate() - (6 - i));
    return d.toISOString().split("T")[0];
  });

  const getRatingColor = (rating: number) => {
    if (rating >= 4) return colors.success;
    if (rating >= 3) return colors.warning;
    if (rating > 0) return colors.error;
    return colors.border || "#e5e7eb";
  };

  const handleSaveEntry = async () => {
    if (todayRating === 0) {
      Alert.alert("Rate your skin", "Please select a rating (1–5) before saving.");
      return;
    }
    setIsSaving(true);
    await addWeeklyEntry({ date: today, skinRating: todayRating, notes });
    setIsSaving(false);
    Alert.alert("Saved!", "Today's skin entry has been recorded. 🌟");
  };

  // Weekly insights via smart analysis
  const handleGenerateInsights = async () => {
    const recentEntries = weeklyEntries.slice(0, 7);
    if (recentEntries.length < 2) {
      Alert.alert("Not enough data", "Log at least 2 days to generate your weekly insights.");
      return;
    }

    setIsGeneratingInsights(true);
    setAiInsights(null);

    try {
      const latestScan = scans[0];
      const entriesSummary = recentEntries
        .map((e) => `${e.date}: rating ${e.skinRating}/5${e.notes ? ` (${e.notes})` : ""}`)
        .join("\n");

      const prompt = `You are a friendly skincare expert for NexSkin, an app for Nigerian users.

Here is a user's skin tracking data for the past week:
${entriesSummary}
${latestScan ? `\nLatest skin scan score: ${Math.round(latestScan.skinScore)}/100\nSkin type: ${latestScan.skinType}` : ""}

Give a warm, personalized 3-point weekly insight summary. Be specific, practical, and encouraging. Format as:
1. What the data shows about their skin pattern this week
2. One specific actionable tip tailored to their ratings (mention Nigerian context like weather/harmattan/humidity if relevant)
3. A positive encouragement for next week

Keep it concise (under 120 words total). Use plain text, no markdown, no asterisks.`;

      const response = await fetch("https://api.anthropic.com/v1/messages", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          model: "claude-sonnet-4-20250514",
          max_tokens: 1000,
          messages: [{ role: "user", content: prompt }],
        }),
      });

      const data = await response.json();
      const text = data.content?.find((b: any) => b.type === "text")?.text || "";
      setAiInsights(text.trim());
    } catch (err) {
      setAiInsights("Unable to generate insights right now. Please try again.");
    } finally {
      setIsGeneratingInsights(false);
    }
  };

  // Weekly average
  const ratedEntries = last7Days
    .map((d) => weeklyEntries.find((e) => e.date === d))
    .filter(Boolean) as typeof weeklyEntries;
  const weekAvg = ratedEntries.length
    ? (ratedEntries.reduce((s, e) => s + e.skinRating, 0) / ratedEntries.length).toFixed(1)
    : null;

  return (
    <ScreenContainer className="p-4">
      <ScrollView contentContainerStyle={{ flexGrow: 1 }} showsVerticalScrollIndicator={false}>
        <View className="gap-6 pb-8">
          {/* Header */}
          <View className="mt-2">
            <Text className="text-3xl font-bold text-foreground">Weekly Tracking</Text>
            <Text className="text-sm text-muted mt-1">Monitor your skin day by day</Text>
          </View>

          {/* Today's entry */}
          <View className="bg-surface rounded-2xl p-4 border border-border gap-4">
            <View className="flex-row justify-between items-center">
              <Text className="text-sm font-semibold text-foreground">Today's Skin Rating</Text>
              {todayRating > 0 && (
                <Text className="text-xs text-primary font-medium">
                  {RATING_EMOJIS[todayRating]} {RATING_LABELS[todayRating]}
                </Text>
              )}
            </View>

            {/* Star-style rating buttons */}
            <View className="flex-row justify-between gap-2">
              {[1, 2, 3, 4, 5].map((rating) => (
                <TouchableOpacity
                  key={rating}
                  onPress={() => setTodayRating(rating)}
                  className="flex-1 items-center gap-1"
                >
                  <View
                    className="w-12 h-12 rounded-full border-2 items-center justify-center"
                    style={{
                      borderColor:
                        todayRating === rating ? getRatingColor(rating) : colors.border || "#e5e7eb",
                      backgroundColor:
                        todayRating === rating ? `${getRatingColor(rating)}25` : "transparent",
                    }}
                  >
                    <Text
                      className="text-lg"
                      style={{
                        color:
                          todayRating === rating ? getRatingColor(rating) : colors.muted,
                        fontWeight: todayRating === rating ? "700" : "400",
                      }}
                    >
                      {rating}
                    </Text>
                  </View>
                  <Text className="text-xs text-muted">{RATING_EMOJIS[rating]}</Text>
                </TouchableOpacity>
              ))}
            </View>
          </View>

          {/* Notes journal */}
          <View className="bg-surface rounded-2xl p-4 border border-border gap-3">
            <View className="flex-row items-center gap-2">
              <MaterialIcons name="edit-note" size={18} color={colors.primary} />
              <Text className="text-sm font-semibold text-foreground">Daily Skin Journal</Text>
            </View>
            <TextInput
              value={notes}
              onChangeText={setNotes}
              placeholder="How does your skin feel today? Any breakouts, dryness, or changes? ..."
              placeholderTextColor={colors.muted}
              multiline
              numberOfLines={4}
              style={{
                borderWidth: 1,
                borderColor: colors.border || "#e5e7eb",
                borderRadius: 12,
                padding: 12,
                minHeight: 100,
                color: colors.foreground,
                fontSize: 14,
                textAlignVertical: "top",
              }}
            />
            <Text className="text-xs text-muted">
              Track what you applied, how your skin felt, weather conditions, diet — anything that
              affects your skin.
            </Text>
          </View>

          {/* Save button */}
          <TouchableOpacity
            onPress={handleSaveEntry}
            disabled={todayRating === 0 || isSaving}
            className="bg-primary rounded-xl py-4 items-center"
            style={{ opacity: todayRating === 0 ? 0.5 : 1 }}
          >
            {isSaving ? (
              <View className="flex-row items-center gap-2">
                <ActivityIndicator size="small" color={colors.background} />
                <Text className="text-base font-semibold text-background">Saving...</Text>
              </View>
            ) : (
              <View className="flex-row items-center gap-2">
                <MaterialIcons name="save" size={18} color={colors.background} />
                <Text className="text-base font-semibold text-background">
                  {todayEntry ? "Update Today's Entry" : "Save Today's Entry"}
                </Text>
              </View>
            )}
          </TouchableOpacity>

          {/* Weekly bar chart */}
          <View>
            <View className="flex-row justify-between items-center mb-3">
              <Text className="text-lg font-semibold text-foreground">This Week</Text>
              {weekAvg && (
                <Text className="text-sm text-muted">
                  Avg: <Text className="font-bold text-foreground">{weekAvg}</Text>/5
                </Text>
              )}
            </View>
            <View className="bg-surface rounded-2xl p-4 border border-border">
              <View className="flex-row justify-between items-end" style={{ height: 100 }}>
                {last7Days.map((date) => {
                  const entry = weeklyEntries.find((e) => e.date === date);
                  const rating = entry?.skinRating || 0;
                  const isToday = date === today;
                  const dayName = new Date(date + "T12:00:00").toLocaleDateString("en-NG", {
                    weekday: "short",
                  });
                  const barColor = isToday
                    ? colors.primary
                    : rating > 0
                    ? getRatingColor(rating)
                    : colors.border || "#e5e7eb";
                  const barHeight = rating > 0 ? (rating / 5) * 80 + 8 : 6;

                  return (
                    <View key={date} className="flex-1 items-center gap-1 mx-0.5">
                      {rating > 0 && (
                        <Text style={{ fontSize: 8, color: colors.muted, marginBottom: 2 }}>
                          {rating}
                        </Text>
                      )}
                      <View
                        style={{
                          width: "100%",
                          height: barHeight,
                          backgroundColor: barColor,
                          borderRadius: 6,
                          alignSelf: "flex-end",
                          opacity: rating === 0 ? 0.3 : 1,
                        }}
                      />
                      <Text
                        style={{
                          fontSize: 10,
                          color: isToday ? colors.primary : colors.muted,
                          fontWeight: isToday ? "700" : "400",
                        }}
                      >
                        {dayName}
                      </Text>
                      {isToday && (
                        <View
                          style={{
                            width: 4,
                            height: 4,
                            borderRadius: 2,
                            backgroundColor: colors.primary,
                          }}
                        />
                      )}
                    </View>
                  );
                })}
              </View>
            </View>
          </View>

          {/* Recent journal entries */}
          {weeklyEntries.filter((e) => e.notes).length > 0 && (
            <View>
              <Text className="text-lg font-semibold text-foreground mb-3">Recent Notes</Text>
              <View className="gap-2">
                {weeklyEntries
                  .filter((e) => e.notes)
                  .slice(0, 3)
                  .map((entry) => (
                    <View key={entry.date} className="bg-surface rounded-xl p-3 border border-border">
                      <View className="flex-row justify-between items-center mb-1">
                        <Text className="text-xs font-medium text-foreground">
                          {new Date(entry.date + "T12:00:00").toLocaleDateString("en-NG", {
                            weekday: "short",
                            month: "short",
                            day: "numeric",
                          })}
                        </Text>
                        <Text className="text-sm">
                          {RATING_EMOJIS[entry.skinRating]} {entry.skinRating}/5
                        </Text>
                      </View>
                      <Text className="text-xs text-muted leading-relaxed">{entry.notes}</Text>
                    </View>
                  ))}
              </View>
            </View>
          )}

          {/* Weekly Insights */}
          <View className="bg-surface rounded-2xl border border-border p-4 gap-3">
            <View className="flex-row justify-between items-center">
              <View className="flex-row items-center gap-2">
                <MaterialIcons name="auto-awesome" size={20} color={colors.primary} />
                <Text className="text-base font-semibold text-foreground">Weekly Insights</Text>
              </View>
              <TouchableOpacity
                onPress={handleGenerateInsights}
                disabled={isGeneratingInsights}
                className="bg-primary rounded-lg px-3 py-1.5"
                style={{ opacity: isGeneratingInsights ? 0.6 : 1 }}
              >
                <Text className="text-xs font-semibold text-background">
                  {isGeneratingInsights ? "Analysing..." : "Generate"}
                </Text>
              </TouchableOpacity>
            </View>

            {isGeneratingInsights ? (
              <View className="items-center gap-3 py-4">
                <ActivityIndicator size="small" color={colors.primary} />
                <Text className="text-xs text-muted">Analysing your week's skin data...</Text>
              </View>
            ) : aiInsights ? (
              <Text className="text-sm text-foreground leading-relaxed">{aiInsights}</Text>
            ) : (
              <Text className="text-xs text-muted">
                Log at least 2 days then tap Generate to get personalised insights about your
                skin patterns, trends, and tips.
              </Text>
            )}
          </View>
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}
