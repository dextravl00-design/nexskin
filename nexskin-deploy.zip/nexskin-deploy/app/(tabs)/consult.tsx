import { ScrollView, Text, View, TouchableOpacity } from "react-native";
import { useRouter } from "expo-router";
import { ScreenContainer } from "@/components/screen-container";
import { useColors } from "@/hooks/use-colors";
import { MaterialIcons } from "@expo/vector-icons";

export default function ConsultScreen() {
  const router = useRouter();
  const colors = useColors();

  // Mock booked consultation
  const bookedConsultation = {
    doctorName: "Dr. Sarah Johnson",
    specialty: "Acne & Rosacea",
    dateTime: "April 15, 2026 • 10:00 AM",
    confirmationId: "CONSULT-20260415-001",
  };

  return (
    <ScreenContainer className="p-4">
      <ScrollView contentContainerStyle={{ flexGrow: 1 }} showsVerticalScrollIndicator={false}>
        <View className="gap-6 pb-8">
          {/* Header */}
          <View className="mt-2">
            <Text className="text-3xl font-bold text-foreground">Consultations</Text>
            <Text className="text-sm text-muted mt-1">Connect with dermatologists</Text>
          </View>

          {/* Booked Consultation */}
          <View className="bg-surface rounded-2xl p-4 border border-border">
            <View className="flex-row justify-between items-start mb-3">
              <Text className="text-sm font-medium text-muted">Upcoming</Text>
              <View className="bg-success/10 rounded-full px-2 py-1">
                <Text className="text-xs font-medium text-success">Confirmed</Text>
              </View>
            </View>
            <Text className="text-base font-semibold text-foreground">
              {bookedConsultation.doctorName}
            </Text>
            <Text className="text-xs text-muted mt-1">{bookedConsultation.specialty}</Text>
            <View className="flex-row items-center gap-2 mt-3 pt-3 border-t border-border">
              <MaterialIcons name="calendar-today" size={14} color={colors.primary} />
              <Text className="text-xs text-foreground">{bookedConsultation.dateTime}</Text>
            </View>
            <View className="flex-row gap-2 mt-3">
              <TouchableOpacity className="flex-1 bg-primary rounded-lg py-2 items-center">
                <Text className="text-xs font-semibold text-background">Join Video Call</Text>
              </TouchableOpacity>
              <TouchableOpacity className="flex-1 bg-surface border border-border rounded-lg py-2 items-center">
                <Text className="text-xs font-semibold text-foreground">Reschedule</Text>
              </TouchableOpacity>
            </View>
          </View>

          {/* Quick Actions */}
          <View className="gap-3">
            <TouchableOpacity
              onPress={() => router.push("../consult-booking")}
              className="bg-primary rounded-2xl p-6 items-center"
            >
              <MaterialIcons name="add-circle-outline" size={32} color={colors.background} />
              <Text className="text-base font-semibold text-background mt-2">
                Book New Consultation
              </Text>
              <Text className="text-xs text-background/80 mt-1">
                Connect with a dermatologist
              </Text>
            </TouchableOpacity>
          </View>

          {/* How It Works */}
          <View className="bg-surface rounded-2xl p-4 border border-border">
            <Text className="text-sm font-semibold text-foreground mb-3">How It Works</Text>
            <View className="gap-3">
              <View className="flex-row items-start gap-3">
                <View
                  className="w-6 h-6 rounded-full items-center justify-center"
                  style={{ backgroundColor: colors.primary }}
                >
                  <Text className="text-xs font-bold text-background">1</Text>
                </View>
                <View className="flex-1">
                  <Text className="text-xs font-medium text-foreground">Select Doctor</Text>
                  <Text className="text-xs text-muted mt-1">
                    Choose from licensed dermatologists
                  </Text>
                </View>
              </View>
              <View className="flex-row items-start gap-3">
                <View
                  className="w-6 h-6 rounded-full items-center justify-center"
                  style={{ backgroundColor: colors.primary }}
                >
                  <Text className="text-xs font-bold text-background">2</Text>
                </View>
                <View className="flex-1">
                  <Text className="text-xs font-medium text-foreground">Pick Time</Text>
                  <Text className="text-xs text-muted mt-1">
                    Choose from available time slots
                  </Text>
                </View>
              </View>
              <View className="flex-row items-start gap-3">
                <View
                  className="w-6 h-6 rounded-full items-center justify-center"
                  style={{ backgroundColor: colors.primary }}
                >
                  <Text className="text-xs font-bold text-background">3</Text>
                </View>
                <View className="flex-1">
                  <Text className="text-xs font-medium text-foreground">Video Call</Text>
                  <Text className="text-xs text-muted mt-1">
                    Join secure video consultation
                  </Text>
                </View>
              </View>
            </View>
          </View>

          {/* Info */}
          <View className="bg-primary/10 rounded-2xl p-4 border border-primary/20">
            <View className="flex-row items-start gap-3">
              <MaterialIcons name="info" size={20} color={colors.primary} />
              <View className="flex-1">
                <Text className="text-sm font-semibold text-foreground mb-1">
                  Professional Advice
                </Text>
                <Text className="text-xs text-muted">
                  Get personalized skincare recommendations from licensed dermatologists
                </Text>
              </View>
            </View>
          </View>
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}
