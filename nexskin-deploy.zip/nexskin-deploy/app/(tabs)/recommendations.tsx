import { ScrollView, Text, View, TouchableOpacity, TextInput, ActivityIndicator, Linking } from "react-native";
import { useRouter } from "expo-router";
import { useState } from "react";
import { ScreenContainer } from "@/components/screen-container";
import { useColors } from "@/hooks/use-colors";
import { useSkinContext } from "@/lib/skin-context";
import { MaterialIcons } from "@expo/vector-icons";

const QUICK_PROMPTS = [
  "Best serum for dark spots",
  "Affordable K-beauty routine",
  "SPF that works on dark skin",
  "Routine for oily acne-prone skin",
  "Hydrating products for dry skin",
  "The Ordinary starter kit",
  "Glass skin routine",
  "Pore minimising products",
  "Budget skincare under ₦10,000",
  "Anti-aging routine for 20s",
];

interface Product {
  name: string;
  brand: string;
  price: string;
  emoji: string;
  category: string;
  tiktokHook: string;
  whyRecommended: string;
  howToUse: string;
  keyIngredients: string[];
  skinTypes: string[];
  where: string;
  rating: string;
}

export default function RecommendationsScreen() {
  const router = useRouter();
  const colors = useColors();
  const { settings } = useSkinContext();
  const [query, setQuery] = useState("");
  const [isSearching, setIsSearching] = useState(false);
  const [products, setProducts] = useState<Product[]>([]);
  const [hasSearched, setHasSearched] = useState(false);
  const [expandedId, setExpandedId] = useState<number | null>(null);
  const [aiMessage, setAiMessage] = useState("");

  const handleSearch = async (searchQuery?: string) => {
    const q = searchQuery ?? query;
    if (!q.trim()) return;
    setQuery(q);
    setIsSearching(true);
    setHasSearched(true);
    setProducts([]);
    setExpandedId(null);
    setAiMessage("");

    try {
      const prompt = `You are a knowledgeable skincare expert for NexSkin, an app used mainly by Nigerian users. The user has ${settings.skinType} skin type.

The user is searching for: "${q}"

Return a JSON object with exactly this structure (no markdown, no extra text, raw JSON only):
{
  "message": "A warm 1-sentence intro about why you picked these products",
  "products": [
    {
      "name": "exact product name",
      "brand": "brand name",
      "price": "₦X,XXX – ₦XX,XXX",
      "emoji": "one relevant emoji",
      "category": "serum|toner|cleanser|moisturizer|sunscreen|treatment|mask|eye-cream|oil|mist",
      "tiktokHook": "the viral TikTok quote or hook for this product (in quotes)",
      "whyRecommended": "1-2 sentences why this matches their query and skin type",
      "howToUse": "concise how-to-use instruction",
      "keyIngredients": ["ingredient 1", "ingredient 2", "ingredient 3"],
      "skinTypes": ["oily", "dry", "combination", "sensitive", "normal"] (only compatible types),
      "where": "where to buy in Nigeria",
      "rating": "4.X/5"
    }
  ]
}

Rules:
- Return 6 to 8 products
- Only include real, popular, widely available skincare products (brands like The Ordinary, COSRX, CeraVe, Paula's Choice, Glow Recipe, La Roche-Posay, Neutrogena, Cetaphil, Garnier, L'Oreal, Olay, Kiehl's, Beauty of Joseon, Innisfree, Tatcha, Drunk Elephant, Laneige, Medik8, etc.)
- Prices in Nigerian Naira (₦) — realistic market prices
- Where to buy must mention Nigerian options (Jumia, Konga, Health Plus, Sephora online, TikTok Shop)
- Make tiktokHook sound genuinely viral and relatable
- Be specific to the user's ${settings.skinType} skin type where relevant
- Return ONLY the raw JSON. No code blocks, no preamble.`;

      const response = await fetch("https://api.anthropic.com/v1/messages", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          model: "claude-sonnet-4-20250514",
          max_tokens: 1000,
          messages: [{ role: "user", content: prompt }],
        }),
      });

      const data = await response.json();
      const text = data.content?.find((b: any) => b.type === "text")?.text ?? "";
      const clean = text.replace(/```json|```/g, "").trim();
      const parsed = JSON.parse(clean);
      setAiMessage(parsed.message ?? "");
      setProducts(parsed.products ?? []);
    } catch (err) {
      setAiMessage("Something went wrong. Please try again.");
    } finally {
      setIsSearching(false);
    }
  };

  const ProductCard = ({ product, index }: { product: Product; index: number }) => {
    const isExpanded = expandedId === index;
    return (
      <View className="rounded-2xl border mb-3 overflow-hidden"
        style={{ backgroundColor: colors.surface, borderColor: colors.border }}>
        <TouchableOpacity onPress={() => setExpandedId(isExpanded ? null : index)} activeOpacity={0.85}>
          <View className="p-4">
            <View className="flex-row gap-3">
              <View className="w-14 h-14 rounded-xl items-center justify-center flex-shrink-0"
                style={{ backgroundColor: `${colors.primary}15` }}>
                <Text style={{ fontSize: 28 }}>{product.emoji}</Text>
              </View>
              <View className="flex-1">
                <Text className="text-sm font-semibold text-foreground" numberOfLines={2}>
                  {product.name}
                </Text>
                <Text className="text-xs font-medium mt-0.5" style={{ color: colors.primary }}>
                  {product.brand}
                </Text>
                <View className="flex-row items-center gap-2 mt-1">
                  <View className="flex-row items-center gap-1">
                    <MaterialIcons name="star" size={11} color={colors.warning} />
                    <Text className="text-xs font-medium text-foreground">{product.rating}</Text>
                  </View>
                  <View className="rounded-full px-2 py-0.5"
                    style={{ backgroundColor: `${colors.primary}12` }}>
                    <Text className="text-xs" style={{ color: colors.primary }}>
                      {product.category}
                    </Text>
                  </View>
                </View>
              </View>
              <View className="items-end justify-between">
                <MaterialIcons
                  name={isExpanded ? "keyboard-arrow-up" : "keyboard-arrow-down"}
                  size={20} color={colors.muted} />
                <Text className="text-sm font-bold" style={{ color: colors.primary }}>
                  {product.price}
                </Text>
              </View>
            </View>

            {/* TikTok hook always visible */}
            <View className="mt-3 rounded-xl p-2.5 flex-row gap-2 items-start"
              style={{ backgroundColor: `${colors.primary}10` }}>
              <Text style={{ fontSize: 13 }}>📱</Text>
              <Text className="text-xs flex-1 leading-relaxed"
                style={{ color: colors.primary, fontStyle: "italic" }}>
                {product.tiktokHook}
              </Text>
            </View>
          </View>
        </TouchableOpacity>

        {/* Expanded detail */}
        {isExpanded && (
          <View style={{ borderTopWidth: 0.5, borderTopColor: colors.border }}>
            <View className="p-4 gap-3">
              {/* Why recommended */}
              <View>
                <Text className="text-xs font-semibold text-foreground mb-1">
                  Why this works for you
                </Text>
                <Text className="text-xs text-muted leading-relaxed">
                  {product.whyRecommended}
                </Text>
              </View>

              {/* Ingredients */}
              <View>
                <Text className="text-xs font-semibold text-foreground mb-1.5">
                  Key Ingredients
                </Text>
                <View className="flex-row flex-wrap gap-1.5">
                  {product.keyIngredients.map((ing, i) => (
                    <View key={i} className="rounded-full px-2.5 py-1"
                      style={{ backgroundColor: `${colors.primary}12`, borderWidth: 0.5, borderColor: `${colors.primary}30` }}>
                      <Text className="text-xs" style={{ color: colors.primary }}>{ing}</Text>
                    </View>
                  ))}
                </View>
              </View>

              {/* How to use */}
              <View>
                <Text className="text-xs font-semibold text-foreground mb-1">How to Use</Text>
                <Text className="text-xs text-muted leading-relaxed">{product.howToUse}</Text>
              </View>

              {/* Skin types */}
              <View className="flex-row flex-wrap gap-1.5">
                {product.skinTypes.map((t, i) => (
                  <View key={i} className="rounded-full px-2.5 py-1"
                    style={{ backgroundColor: `${colors.success}15` }}>
                    <Text className="text-xs" style={{ color: colors.success }}>
                      ✓ {t}
                    </Text>
                  </View>
                ))}
              </View>

              {/* Where to buy + button */}
              <View>
                <Text className="text-xs text-muted mb-2">
                  <Text className="font-semibold text-foreground">Where to buy: </Text>
                  {product.where}
                </Text>
                <TouchableOpacity
                  onPress={() => Linking.openURL("https://www.jumia.com.ng/catalog/?q=" + encodeURIComponent(product.name + " " + product.brand))}
                  className="rounded-xl py-3 items-center flex-row justify-center gap-2"
                  style={{ backgroundColor: colors.primary }}>
                  <MaterialIcons name="shopping-cart" size={16} color={colors.surface} />
                  <Text className="text-sm font-semibold" style={{ color: colors.surface }}>
                    Search on Jumia
                  </Text>
                </TouchableOpacity>
              </View>
            </View>
          </View>
        )}
      </View>
    );
  };

  return (
    <ScreenContainer className="p-4">
      <ScrollView contentContainerStyle={{ flexGrow: 1 }} showsVerticalScrollIndicator={false}
        keyboardShouldPersistTaps="handled">
        <View className="gap-4 pb-8">
          {/* Header */}
          <View className="mt-2">
            <Text className="text-3xl font-bold text-foreground">Skincare Search</Text>
            <Text className="text-sm text-muted mt-1">
              Smart picks · Ask anything about skincare
            </Text>
          </View>

          {/* Search bar */}
          <View className="rounded-2xl border overflow-hidden"
            style={{ backgroundColor: colors.surface, borderColor: colors.border }}>
            <View className="flex-row items-center px-4 py-3 gap-3">
              <MaterialIcons name="auto-awesome" size={20} color={colors.primary} />
              <TextInput
                value={query}
                onChangeText={setQuery}
                onSubmitEditing={() => handleSearch()}
                placeholder="e.g. best serum for dark spots..."
                placeholderTextColor={colors.muted}
                returnKeyType="search"
                style={{
                  flex: 1,
                  fontSize: 14,
                  color: colors.foreground,
                  paddingVertical: 0,
                }}
              />
              {query.length > 0 && (
                <TouchableOpacity onPress={() => { setQuery(""); setProducts([]); setHasSearched(false); }}>
                  <MaterialIcons name="close" size={18} color={colors.muted} />
                </TouchableOpacity>
              )}
            </View>
            <TouchableOpacity
              onPress={() => handleSearch()}
              disabled={isSearching || !query.trim()}
              className="mx-4 mb-3 rounded-xl py-3 items-center"
              style={{
                backgroundColor: colors.primary,
                opacity: !query.trim() ? 0.4 : 1,
              }}>
              {isSearching ? (
                <View className="flex-row items-center gap-2">
                  <ActivityIndicator size="small" color={colors.surface} />
                  <Text className="text-sm font-semibold" style={{ color: colors.surface }}>
                    Finding products...
                  </Text>
                </View>
              ) : (
                <View className="flex-row items-center gap-2">
                  <MaterialIcons name="search" size={18} color={colors.surface} />
                  <Text className="text-sm font-semibold" style={{ color: colors.surface }}>
                    Find Products
                  </Text>
                </View>
              )}
            </TouchableOpacity>
          </View>

          {/* Quick prompts */}
          {!hasSearched && (
            <View>
              <Text className="text-sm font-semibold text-foreground mb-2">
                Popular searches
              </Text>
              <View className="flex-row flex-wrap gap-2">
                {QUICK_PROMPTS.map((p) => (
                  <TouchableOpacity
                    key={p}
                    onPress={() => handleSearch(p)}
                    className="rounded-full px-3 py-2 border"
                    style={{ backgroundColor: colors.surface, borderColor: colors.border }}>
                    <Text className="text-xs text-foreground">{p}</Text>
                  </TouchableOpacity>
                ))}
              </View>
            </View>
          )}

          {/* Loading state */}
          {isSearching && (
            <View className="rounded-2xl p-8 border items-center gap-4"
              style={{ backgroundColor: colors.surface, borderColor: colors.border }}>
              <Text style={{ fontSize: 36 }}>🔍</Text>
              <Text className="text-sm font-medium text-foreground">
                Searching the skincare world...
              </Text>
              <Text className="text-xs text-muted text-center">
                Finding the best products for your {settings.skinType} skin
              </Text>
            </View>
          )}

          {/* Response message */}
          {aiMessage && !isSearching && (
            <View className="rounded-2xl p-4 border flex-row gap-3"
              style={{ backgroundColor: `${colors.primary}10`, borderColor: `${colors.primary}25` }}>
              <Text style={{ fontSize: 18 }}>✨</Text>
              <Text className="text-sm flex-1 leading-relaxed" style={{ color: colors.primary }}>
                {aiMessage}
              </Text>
            </View>
          )}

          {/* Results */}
          {!isSearching && products.length > 0 && (
            <View>
              <Text className="text-sm font-semibold text-foreground mb-2">
                {products.length} products found · tap any to expand
              </Text>
              {products.map((p, i) => (
                <ProductCard key={i} product={p} index={i} />
              ))}
            </View>
          )}

          {/* No results */}
          {hasSearched && !isSearching && products.length === 0 && !aiMessage && (
            <View className="rounded-2xl p-8 border items-center gap-3"
              style={{ backgroundColor: colors.surface, borderColor: colors.border }}>
              <MaterialIcons name="search-off" size={40} color={colors.muted} />
              <Text className="text-base font-medium text-foreground">No results found</Text>
              <Text className="text-sm text-muted text-center">Try a different search term</Text>
            </View>
          )}

          {/* Tip card when idle */}
          {!hasSearched && (
            <View className="rounded-2xl p-4 border"
              style={{ backgroundColor: colors.surface, borderColor: colors.border }}>
              <View className="flex-row gap-3 items-start">
                <Text style={{ fontSize: 18 }}>💡</Text>
                <View className="flex-1">
                  <Text className="text-sm font-semibold text-foreground mb-1">
                    How to get the best results
                  </Text>
                  <Text className="text-xs text-muted leading-relaxed">
                    Be specific in your search. Try "serum for hyperpigmentation on dark skin" or
                    "morning routine for oily skin under ₦20,000" for more targeted recommendations.
                  </Text>
                </View>
              </View>
            </View>
          )}
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}
