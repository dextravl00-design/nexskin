import { ScrollView, Text, View, TouchableOpacity, Switch } from "react-native";
import { useRouter } from "expo-router";
import { useState } from "react";
import { ScreenContainer } from "@/components/screen-container";
import { useColors } from "@/hooks/use-colors";
import { useSkinContext } from "@/lib/skin-context";
import { useTheme } from "@/lib/theme-provider";
import { MaterialIcons } from "@expo/vector-icons";

export default function SettingsScreen() {
  const router = useRouter();
  const colors = useColors();
  const { settings, updateSettings } = useSkinContext();
  const { colorScheme, setColorScheme } = useTheme();
  const [notificationsEnabled, setNotificationsEnabled] = useState(settings.notificationsEnabled);

  const handleNotificationToggle = async (value: boolean) => {
    setNotificationsEnabled(value);
    await updateSettings({
      ...settings,
      notificationsEnabled: value,
    });
  };

  const handleThemeToggle = () => {
    const newScheme = colorScheme === "light" ? "dark" : "light";
    setColorScheme(newScheme);
  };

  const SettingItem = ({
    icon,
    label,
    value,
    onPress,
  }: {
    icon: string;
    label: string;
    value?: string;
    onPress?: () => void;
  }) => (
    <TouchableOpacity
      onPress={onPress}
      className="flex-row items-center justify-between py-4 border-b border-border"
    >
      <View className="flex-row items-center gap-3 flex-1">
        <MaterialIcons name={icon as any} size={20} color={colors.primary} />
        <View className="flex-1">
          <Text className="text-sm font-medium text-foreground">{label}</Text>
          {value && <Text className="text-xs text-muted mt-1">{value}</Text>}
        </View>
      </View>
      <MaterialIcons name="chevron-right" size={20} color={colors.muted} />
    </TouchableOpacity>
  );

  return (
    <ScreenContainer className="p-4">
      <ScrollView contentContainerStyle={{ flexGrow: 1 }} showsVerticalScrollIndicator={false}>
        <View className="gap-6 pb-8">
          {/* Header */}
          <View className="mt-2">
            <Text className="text-3xl font-bold text-foreground">Settings</Text>
            <Text className="text-sm text-muted mt-1">Manage your preferences</Text>
          </View>

          {/* Profile Section */}
          <View>
            <Text className="text-sm font-semibold text-foreground mb-3">Profile</Text>
            <View className="bg-surface rounded-2xl p-4 border border-border">
              <View className="flex-row items-center gap-4 mb-4">
                <View
                  className="w-16 h-16 rounded-full items-center justify-center"
                  style={{ backgroundColor: colors.primary }}
                >
                  <MaterialIcons name="person" size={32} color={colors.background} />
                </View>
                <View className="flex-1">
                  <Text className="text-base font-semibold text-foreground">User Profile</Text>
                  <Text className="text-xs text-muted mt-1">
                    {settings.skinType.charAt(0).toUpperCase() + settings.skinType.slice(1)} Skin
                  </Text>
                </View>
              </View>
              <TouchableOpacity className="bg-primary rounded-lg py-2 items-center">
                <Text className="text-sm font-semibold text-background">Edit Profile</Text>
              </TouchableOpacity>
            </View>
          </View>

          {/* Preferences Section */}
          <View>
            <Text className="text-sm font-semibold text-foreground mb-3">Preferences</Text>
            <View className="bg-surface rounded-2xl p-4 border border-border">
              {/* Skin Type */}
              <SettingItem
                icon="face"
                label="Skin Type"
                value={settings.skinType.charAt(0).toUpperCase() + settings.skinType.slice(1)}
                onPress={() => {}}
              />

              {/* Routine Times */}
              <SettingItem
                icon="schedule"
                label="Morning Routine Time"
                value={settings.morningRoutineTime}
                onPress={() => {}}
              />
              <SettingItem
                icon="schedule"
                label="Night Routine Time"
                value={settings.nightRoutineTime}
                onPress={() => {}}
              />

              {/* Theme */}
              <TouchableOpacity
                onPress={handleThemeToggle}
                className="flex-row items-center justify-between py-4 border-b border-border"
              >
                <View className="flex-row items-center gap-3">
                  <MaterialIcons
                    name={colorScheme === "dark" ? "dark-mode" : "light-mode"}
                    size={20}
                    color={colors.primary}
                  />
                  <Text className="text-sm font-medium text-foreground">
                    {colorScheme === "dark" ? "Dark Mode" : "Light Mode"}
                  </Text>
                </View>
                <Switch
                  value={colorScheme === "dark"}
                  onValueChange={handleThemeToggle}
                  trackColor={{ false: colors.border, true: colors.primary }}
                />
              </TouchableOpacity>

              {/* Notifications */}
              <TouchableOpacity
                onPress={() => handleNotificationToggle(!notificationsEnabled)}
                className="flex-row items-center justify-between py-4"
              >
                <View className="flex-row items-center gap-3">
                  <MaterialIcons name="notifications" size={20} color={colors.primary} />
                  <Text className="text-sm font-medium text-foreground">
                    Push Notifications
                  </Text>
                </View>
                <Switch
                  value={notificationsEnabled}
                  onValueChange={handleNotificationToggle}
                  trackColor={{ false: colors.border, true: colors.primary }}
                />
              </TouchableOpacity>
            </View>
          </View>

          {/* Support Section */}
          <View>
            <Text className="text-sm font-semibold text-foreground mb-3">Support</Text>
            <View className="bg-surface rounded-2xl p-4 border border-border">
              <SettingItem
                icon="help"
                label="Help & Support"
                onPress={() => {}}
              />
              <SettingItem
                icon="description"
                label="Privacy Policy"
                onPress={() => {}}
              />
              <SettingItem
                icon="description"
                label="Terms of Service"
                onPress={() => {}}
              />
              <TouchableOpacity className="flex-row items-center justify-between py-4">
                <View className="flex-row items-center gap-3">
                  <MaterialIcons name="info" size={20} color={colors.primary} />
                  <View>
                    <Text className="text-sm font-medium text-foreground">App Version</Text>
                    <Text className="text-xs text-muted mt-1">1.0.0</Text>
                  </View>
                </View>
              </TouchableOpacity>
            </View>
          </View>

          {/* Vendor Portal */}
          <View>
            <Text className="text-sm font-semibold text-foreground mb-3">Vendor Portal</Text>
            <View className="bg-surface rounded-2xl border border-border overflow-hidden">
              <TouchableOpacity
                onPress={() => router.push("../../vendor/onboarding")}
                className="flex-row items-center justify-between p-4"
                style={{ borderBottomWidth: 0.5, borderBottomColor: colors.border }}
              >
                <View className="flex-row items-center gap-3">
                  <View className="w-8 h-8 rounded-full items-center justify-center" style={{ backgroundColor: `${colors.primary}15` }}>
                    <MaterialIcons name="storefront" size={18} color={colors.primary} />
                  </View>
                  <View>
                    <Text className="text-sm font-medium text-foreground">Sell on NexSkin</Text>
                    <Text className="text-xs text-muted mt-0.5">Register your skincare store</Text>
                  </View>
                </View>
                <MaterialIcons name="chevron-right" size={20} color={colors.muted} />
              </TouchableOpacity>
              <TouchableOpacity
                onPress={() => router.push("../../vendor/dashboard")}
                className="flex-row items-center justify-between p-4"
              >
                <View className="flex-row items-center gap-3">
                  <View className="w-8 h-8 rounded-full items-center justify-center" style={{ backgroundColor: `${colors.primary}15` }}>
                    <MaterialIcons name="dashboard" size={18} color={colors.primary} />
                  </View>
                  <View>
                    <Text className="text-sm font-medium text-foreground">Vendor Dashboard</Text>
                    <Text className="text-xs text-muted mt-0.5">Manage products & orders</Text>
                  </View>
                </View>
                <MaterialIcons name="chevron-right" size={20} color={colors.muted} />
              </TouchableOpacity>
            </View>
          </View>

          {/* Danger Zone */}
          <View>
            <Text className="text-sm font-semibold text-error mb-3">Danger Zone</Text>
            <TouchableOpacity className="bg-error/10 border border-error rounded-2xl p-4 items-center">
              <Text className="text-sm font-semibold text-error">Delete Account</Text>
            </TouchableOpacity>
          </View>
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}
