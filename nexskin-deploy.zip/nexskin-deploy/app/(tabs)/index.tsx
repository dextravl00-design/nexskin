import { ScrollView, Text, View, TouchableOpacity } from "react-native";
import { useRouter } from "expo-router";
import { ScreenContainer } from "@/components/screen-container";
import { useSkinContext } from "@/lib/skin-context";
import { useColors } from "@/hooks/use-colors";
import { MaterialIcons } from "@expo/vector-icons";

function ScoreRing({ score }: { score: number }) {
  const colors = useColors();
  const color = score >= 80 ? colors.success : score >= 60 ? colors.warning : colors.error;
  const label = score >= 80 ? "Excellent" : score >= 60 ? "Good" : score > 0 ? "Needs Care" : "No Data";
  return (
    <View className="items-center gap-2">
      <View
        className="w-28 h-28 rounded-full items-center justify-center border-4"
        style={{ borderColor: score > 0 ? color : colors.border }}
      >
        <Text className="text-4xl font-bold" style={{ color: score > 0 ? color : colors.muted }}>
          {score > 0 ? Math.round(score) : "--"}
        </Text>
        <Text className="text-xs text-muted">/100</Text>
      </View>
      <Text className="text-sm font-semibold" style={{ color: score > 0 ? color : colors.muted }}>
        {label}
      </Text>
    </View>
  );
}

export default function HomeScreen() {
  const router = useRouter();
  const colors = useColors();
  const { getLatestScan, settings, weeklyEntries } = useSkinContext();
  const latestScan = getLatestScan();
  const todayEntry = weeklyEntries.find(
    (e) => e.date === new Date().toISOString().split("T")[0]
  );

  return (
    <ScreenContainer className="p-4">
      <ScrollView contentContainerStyle={{ flexGrow: 1 }} showsVerticalScrollIndicator={false}>
        <View className="gap-6 pb-8">
          {/* Header */}
          <View className="mt-2 flex-row justify-between items-start">
            <View>
              <Text className="text-3xl font-bold text-foreground">
                {settings.name ? `Hi, ${settings.name} 👋` : "Welcome to NexSkin"}
              </Text>
              <Text className="text-sm text-muted mt-1">Your skin health dashboard</Text>
            </View>
            <TouchableOpacity onPress={() => router.push("../scan")}>
              <View
                className="w-12 h-12 rounded-full items-center justify-center"
                style={{ backgroundColor: colors.primary }}
              >
                <MaterialIcons name="camera-alt" size={22} color={colors.surface} />
              </View>
            </TouchableOpacity>
          </View>

          {/* Score card */}
          <View
            className="rounded-3xl p-6 border"
            style={{ backgroundColor: colors.surface, borderColor: colors.border }}
          >
            <View className="flex-row justify-between items-center">
              <View className="flex-1">
                <Text className="text-sm font-semibold text-muted mb-1">Skin Score</Text>
                <Text className="text-xs text-muted">
                  {latestScan
                    ? `Last scanned ${new Date(latestScan.timestamp).toLocaleDateString("en-NG", { month: "short", day: "numeric" })}`
                    : "Scan your skin to get started"}
                </Text>
                {latestScan && (
                  <Text className="text-xs text-muted mt-2 capitalize">
                    {latestScan.skinType} skin type
                  </Text>
                )}
              </View>
              <ScoreRing score={latestScan?.skinScore ?? 0} />
            </View>

            {latestScan && (
              <View className="flex-row gap-3 mt-4 pt-4" style={{ borderTopWidth: 1, borderTopColor: colors.border }}>
                {[
                  { label: "Hydration", value: latestScan.metrics.hydration + "%" },
                  { label: "Redness", value: latestScan.metrics.redness },
                  { label: "Texture", value: latestScan.metrics.texture + "%" },
                ].map((m) => (
                  <View key={m.label} className="flex-1 items-center">
                    <Text className="text-base font-bold text-foreground">{m.value}</Text>
                    <Text className="text-xs text-muted">{m.label}</Text>
                  </View>
                ))}
              </View>
            )}
          </View>

          {/* Quick actions */}
          <View>
            <Text className="text-lg font-semibold text-foreground mb-3">Quick Actions</Text>
            <View className="flex-row gap-3">
              {[
                { icon: "camera-alt", label: "Scan Skin", route: "../scan", primary: true },
                { icon: "repeat", label: "Routine", route: "../routine", primary: false },
                { icon: "history", label: "History", route: "../history", primary: false },
              ].map((a) => (
                <TouchableOpacity
                  key={a.label}
                  onPress={() => router.push(a.route as any)}
                  className="flex-1 rounded-2xl py-4 items-center gap-2"
                  style={{
                    backgroundColor: a.primary ? colors.primary : colors.surface,
                    borderWidth: a.primary ? 0 : 1,
                    borderColor: colors.border,
                  }}
                >
                  <MaterialIcons
                    name={a.icon as any}
                    size={24}
                    color={a.primary ? colors.surface : colors.primary}
                  />
                  <Text
                    className="text-xs font-semibold"
                    style={{ color: a.primary ? colors.surface : colors.foreground }}
                  >
                    {a.label}
                  </Text>
                </TouchableOpacity>
              ))}
            </View>
          </View>

          {/* Today's check-in */}
          <View
            className="rounded-2xl p-4 border"
            style={{ backgroundColor: colors.surface, borderColor: colors.border }}
          >
            <View className="flex-row justify-between items-center mb-3">
              <Text className="text-sm font-semibold text-foreground">Today's Check-in</Text>
              {todayEntry && <Text className="text-lg">{["", "😟", "😕", "😐", "🙂", "😊"][todayEntry.skinRating]}</Text>}
            </View>
            {todayEntry ? (
              <View>
                <Text className="text-sm text-foreground">Skin rated {todayEntry.skinRating}/5 today</Text>
                {todayEntry.notes ? (
                  <Text className="text-xs text-muted mt-1" numberOfLines={2}>{todayEntry.notes}</Text>
                ) : null}
              </View>
            ) : (
              <TouchableOpacity
                onPress={() => router.push("../tracking")}
                className="rounded-xl py-3 items-center"
                style={{ backgroundColor: `${colors.primary}15` }}
              >
                <Text className="text-sm font-semibold" style={{ color: colors.primary }}>
                  Rate your skin today
                </Text>
              </TouchableOpacity>
            )}
          </View>

          {/* Get started CTA */}
          {!latestScan && (
            <View
              className="rounded-2xl p-6 border"
              style={{ backgroundColor: `${colors.primary}12`, borderColor: `${colors.primary}40` }}
            >
              <Text className="text-lg font-semibold text-foreground mb-2">Get Started 🌟</Text>
              <Text className="text-sm text-muted mb-4">
                Take your first skin scan to get personalised recommendations for your skin type.
              </Text>
              <TouchableOpacity
                onPress={() => router.push("../scan")}
                className="rounded-xl py-3 items-center"
                style={{ backgroundColor: colors.primary }}
              >
                <Text className="text-base font-semibold" style={{ color: colors.surface }}>
                  Start First Scan
                </Text>
              </TouchableOpacity>
            </View>
          )}
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}
