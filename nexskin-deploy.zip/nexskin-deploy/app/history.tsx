import { useState } from "react";
import { ScrollView, Text, View, TouchableOpacity, Dimensions } from "react-native";
import { useRouter } from "expo-router";
import { ScreenContainer } from "@/components/screen-container";
import { useColors } from "@/hooks/use-colors";
import { useSkinContext } from "@/lib/skin-context";
import { MaterialIcons } from "@expo/vector-icons";
import { SkinScan } from "@/lib/types";

const { width: SCREEN_WIDTH } = Dimensions.get("window");
const CHART_WIDTH = SCREEN_WIDTH - 64;
const CHART_HEIGHT = 140;

export default function HistoryScreen() {
  const router = useRouter();
  const colors = useColors();
  const { scans } = useSkinContext();

  const [mode, setMode] = useState<"list" | "compare" | "trend">("list");
  const [compareSelected, setCompareSelected] = useState<string[]>([]);

  const getScoreColor = (score: number) => {
    if (score >= 80) return colors.success;
    if (score >= 60) return colors.warning;
    return colors.error;
  };

  // ── Compare mode helpers ─────────────────────────────────────────
  const toggleCompareSelect = (id: string) => {
    if (compareSelected.includes(id)) {
      setCompareSelected(compareSelected.filter((s) => s !== id));
    } else if (compareSelected.length < 2) {
      setCompareSelected([...compareSelected, id]);
    }
  };

  const scanA = scans.find((s) => s.id === compareSelected[0]);
  const scanB = scans.find((s) => s.id === compareSelected[1]);

  // ── Trend chart helpers ──────────────────────────────────────────
  const trendScans = [...scans].reverse().slice(-10); // oldest first, max 10

  const buildPolyline = () => {
    if (trendScans.length < 2) return "";
    const minScore = Math.min(...trendScans.map((s) => s.skinScore), 0);
    const maxScore = Math.max(...trendScans.map((s) => s.skinScore), 100);
    const range = maxScore - minScore || 1;
    return trendScans
      .map((s, i) => {
        const x = (i / (trendScans.length - 1)) * CHART_WIDTH;
        const y = CHART_HEIGHT - ((s.skinScore - minScore) / range) * CHART_HEIGHT;
        return `${x},${y}`;
      })
      .join(" ");
  };

  const METRIC_LABELS: Record<string, string> = {
    hydration: "Hydration",
    poreSize: "Pore Size",
    darkSpots: "Dark Spots",
    redness: "Redness",
    texture: "Texture",
  };

  const metricDiff = (key: keyof SkinScan["metrics"], invert = false) => {
    if (!scanA || !scanB) return null;
    const a = scanA.metrics[key] as number;
    const b = scanB.metrics[key] as number;
    const raw = b - a;
    const good = invert ? raw < 0 : raw > 0;
    return { a, b, raw, good };
  };

  // ── Scan list item ───────────────────────────────────────────────
  const ScanItem = ({ scan }: { scan: SkinScan }) => {
    const scoreColor = getScoreColor(scan.skinScore);
    const isSelected = compareSelected.includes(scan.id);
    return (
      <TouchableOpacity
        onPress={() =>
          mode === "compare"
            ? toggleCompareSelect(scan.id)
            : router.push(`../scan-results?id=${scan.id}`)
        }
        className="bg-surface rounded-2xl p-4 border mb-3 flex-row justify-between items-center"
        style={{
          borderColor: isSelected ? colors.primary : colors.border || "#e5e7eb",
          backgroundColor: isSelected ? `${colors.primary}12` : undefined,
        }}
      >
        <View className="flex-1">
          <Text className="text-sm font-medium text-foreground">
            {new Date(scan.timestamp).toLocaleDateString("en-NG", {
              weekday: "short",
              month: "short",
              day: "numeric",
            })}
          </Text>
          <Text className="text-xs text-muted mt-0.5 capitalize">{scan.skinType} Skin</Text>
          <View className="flex-row gap-3 mt-2">
            {(["hydration", "redness"] as const).map((key) => (
              <Text key={key} className="text-xs text-muted">
                {METRIC_LABELS[key]}: {scan.metrics[key]}
              </Text>
            ))}
          </View>
        </View>
        <View className="items-center ml-3">
          {mode === "compare" && (
            <View
              className="w-6 h-6 rounded-full border-2 items-center justify-center mb-2"
              style={{
                borderColor: isSelected ? colors.primary : colors.border || "#e5e7eb",
                backgroundColor: isSelected ? colors.primary : "transparent",
              }}
            >
              {isSelected && <MaterialIcons name="check" size={14} color={colors.background} />}
            </View>
          )}
          <Text className="text-2xl font-bold" style={{ color: scoreColor }}>
            {Math.round(scan.skinScore)}
          </Text>
          <Text className="text-xs text-muted">Score</Text>
        </View>
      </TouchableOpacity>
    );
  };

  // ── Compare panel ────────────────────────────────────────────────
  const ComparePanel = () => {
    if (!scanA || !scanB) return null;
    const metrics: { key: keyof SkinScan["metrics"]; label: string; invert?: boolean }[] = [
      { key: "hydration", label: "Hydration %" },
      { key: "poreSize", label: "Pore Size", invert: true },
      { key: "darkSpots", label: "Dark Spots", invert: true },
      { key: "redness", label: "Redness", invert: true },
      { key: "texture", label: "Texture %" },
    ];

    return (
      <View className="bg-surface rounded-2xl border border-border p-4 mb-4">
        <Text className="text-base font-bold text-foreground mb-4 text-center">
          Side-by-Side Comparison
        </Text>

        {/* Date headers */}
        <View className="flex-row mb-3">
          <View className="flex-1" />
          <View
            className="flex-1 items-center rounded-lg py-1 mr-1"
            style={{ backgroundColor: `${colors.primary}20` }}
          >
            <Text className="text-xs font-semibold text-primary">
              {new Date(scanA.timestamp).toLocaleDateString("en-NG", { month: "short", day: "numeric" })}
            </Text>
          </View>
          <View
            className="flex-1 items-center rounded-lg py-1"
            style={{ backgroundColor: `${colors.success}20` }}
          >
            <Text className="text-xs font-semibold" style={{ color: colors.success }}>
              {new Date(scanB.timestamp).toLocaleDateString("en-NG", { month: "short", day: "numeric" })}
            </Text>
          </View>
        </View>

        {/* Score row */}
        <View className="flex-row items-center mb-3 pb-3 border-b border-border">
          <Text className="flex-1 text-xs font-bold text-foreground">Overall Score</Text>
          <Text className="flex-1 text-center text-xl font-bold" style={{ color: colors.primary }}>
            {Math.round(scanA.skinScore)}
          </Text>
          <View className="flex-1 items-center flex-row justify-center gap-1">
            <Text className="text-xl font-bold" style={{ color: colors.success }}>
              {Math.round(scanB.skinScore)}
            </Text>
            {scanB.skinScore !== scanA.skinScore && (
              <MaterialIcons
                name={scanB.skinScore > scanA.skinScore ? "trending-up" : "trending-down"}
                size={16}
                color={scanB.skinScore > scanA.skinScore ? colors.success : colors.error}
              />
            )}
          </View>
        </View>

        {/* Metrics rows */}
        {metrics.map(({ key, label, invert }) => {
          const diff = metricDiff(key, invert);
          if (!diff) return null;
          return (
            <View key={key} className="flex-row items-center mb-2">
              <Text className="flex-1 text-xs text-muted">{label}</Text>
              <Text className="flex-1 text-center text-sm font-medium text-foreground">
                {diff.a}
              </Text>
              <View className="flex-1 flex-row items-center justify-center gap-1">
                <Text className="text-sm font-medium text-foreground">{diff.b}</Text>
                {diff.raw !== 0 && (
                  <MaterialIcons
                    name={diff.good ? "arrow-upward" : "arrow-downward"}
                    size={12}
                    color={diff.good ? colors.success : colors.error}
                  />
                )}
              </View>
            </View>
          );
        })}
      </View>
    );
  };

  // ── Trend chart ──────────────────────────────────────────────────
  const TrendChart = () => {
    if (trendScans.length < 2) {
      return (
        <View className="bg-surface rounded-2xl border border-border p-8 items-center gap-3 mb-4">
          <MaterialIcons name="show-chart" size={36} color={colors.muted} />
          <Text className="text-sm text-muted text-center">
            You need at least 2 scans to see your trend chart.
          </Text>
        </View>
      );
    }

    const polyline = buildPolyline();
    const minScore = Math.min(...trendScans.map((s) => s.skinScore));
    const maxScore = Math.max(...trendScans.map((s) => s.skinScore));
    const latest = trendScans[trendScans.length - 1];
    const first = trendScans[0];
    const overallChange = latest.skinScore - first.skinScore;

    return (
      <View className="bg-surface rounded-2xl border border-border p-4 mb-4">
        <View className="flex-row justify-between items-center mb-4">
          <Text className="text-base font-bold text-foreground">Score Trend</Text>
          <View className="flex-row items-center gap-1">
            <MaterialIcons
              name={overallChange >= 0 ? "trending-up" : "trending-down"}
              size={18}
              color={overallChange >= 0 ? colors.success : colors.error}
            />
            <Text
              className="text-sm font-semibold"
              style={{ color: overallChange >= 0 ? colors.success : colors.error }}
            >
              {overallChange >= 0 ? "+" : ""}{Math.round(overallChange)} pts
            </Text>
          </View>
        </View>

        {/* SVG chart */}
        <View style={{ width: CHART_WIDTH, height: CHART_HEIGHT + 24 }}>
          {/* Y-axis labels */}
          <Text style={{ position: "absolute", top: 0, left: 0, fontSize: 9, color: colors.muted }}>
            {Math.round(maxScore)}
          </Text>
          <Text style={{ position: "absolute", bottom: 20, left: 0, fontSize: 9, color: colors.muted }}>
            {Math.round(minScore)}
          </Text>

          {/* Grid lines */}
          {[0, 0.5, 1].map((frac) => (
            <View
              key={frac}
              style={{
                position: "absolute",
                left: 16,
                right: 0,
                top: frac * CHART_HEIGHT,
                height: 1,
                backgroundColor: `${colors.border}60`,
              }}
            />
          ))}

          {/* Polyline using View segments */}
          {trendScans.map((scan, i) => {
            if (i === 0) return null;
            const prev = trendScans[i - 1];
            const minS = Math.min(...trendScans.map((s) => s.skinScore));
            const maxS = Math.max(...trendScans.map((s) => s.skinScore));
            const range = maxS - minS || 1;
            const x1 = 16 + ((i - 1) / (trendScans.length - 1)) * (CHART_WIDTH - 16);
            const x2 = 16 + (i / (trendScans.length - 1)) * (CHART_WIDTH - 16);
            const y1 = CHART_HEIGHT - ((prev.skinScore - minS) / range) * CHART_HEIGHT;
            const y2 = CHART_HEIGHT - ((scan.skinScore - minS) / range) * CHART_HEIGHT;
            const length = Math.sqrt((x2 - x1) ** 2 + (y2 - y1) ** 2);
            const angle = (Math.atan2(y2 - y1, x2 - x1) * 180) / Math.PI;

            return (
              <View
                key={i}
                style={{
                  position: "absolute",
                  left: x1,
                  top: y1,
                  width: length,
                  height: 2.5,
                  backgroundColor: colors.primary,
                  transformOrigin: "0 50%",
                  transform: [{ rotate: `${angle}deg` }],
                  borderRadius: 2,
                }}
              />
            );
          })}

          {/* Dots */}
          {trendScans.map((scan, i) => {
            const minS = Math.min(...trendScans.map((s) => s.skinScore));
            const maxS = Math.max(...trendScans.map((s) => s.skinScore));
            const range = maxS - minS || 1;
            const x = 16 + (i / (trendScans.length - 1)) * (CHART_WIDTH - 16);
            const y = CHART_HEIGHT - ((scan.skinScore - minS) / range) * CHART_HEIGHT;
            return (
              <View
                key={scan.id}
                style={{
                  position: "absolute",
                  left: x - 5,
                  top: y - 5,
                  width: 10,
                  height: 10,
                  borderRadius: 5,
                  backgroundColor: colors.primary,
                  borderWidth: 2,
                  borderColor: colors.background,
                }}
              />
            );
          })}

          {/* X-axis date labels */}
          {trendScans.map((scan, i) => {
            if (trendScans.length > 5 && i % 2 !== 0) return null;
            const x = 16 + (i / (trendScans.length - 1)) * (CHART_WIDTH - 16);
            const label = new Date(scan.timestamp).toLocaleDateString("en-NG", {
              month: "short",
              day: "numeric",
            });
            return (
              <Text
                key={scan.id}
                style={{
                  position: "absolute",
                  left: x - 18,
                  top: CHART_HEIGHT + 6,
                  fontSize: 9,
                  color: colors.muted,
                  width: 36,
                  textAlign: "center",
                }}
              >
                {label}
              </Text>
            );
          })}
        </View>

        {/* Stats row */}
        <View className="flex-row justify-around mt-4 pt-3 border-t border-border">
          <View className="items-center">
            <Text className="text-lg font-bold text-foreground">{Math.round(latest.skinScore)}</Text>
            <Text className="text-xs text-muted">Latest</Text>
          </View>
          <View className="items-center">
            <Text className="text-lg font-bold text-foreground">
              {Math.round(trendScans.reduce((s, sc) => s + sc.skinScore, 0) / trendScans.length)}
            </Text>
            <Text className="text-xs text-muted">Average</Text>
          </View>
          <View className="items-center">
            <Text className="text-lg font-bold text-foreground">{Math.round(maxScore)}</Text>
            <Text className="text-xs text-muted">Best</Text>
          </View>
          <View className="items-center">
            <Text className="text-lg font-bold text-foreground">{trendScans.length}</Text>
            <Text className="text-xs text-muted">Scans</Text>
          </View>
        </View>
      </View>
    );
  };

  return (
    <ScreenContainer className="p-4">
      <ScrollView contentContainerStyle={{ flexGrow: 1 }} showsVerticalScrollIndicator={false}>
        <View className="gap-4 pb-8">
          {/* Header */}
          <View className="flex-row justify-between items-center mt-2">
            <View>
              <Text className="text-3xl font-bold text-foreground">Skin History</Text>
              <Text className="text-sm text-muted mt-1">
                {scans.length} scan{scans.length !== 1 ? "s" : ""} recorded
              </Text>
            </View>
            <TouchableOpacity onPress={() => router.back()}>
              <MaterialIcons name="close" size={28} color={colors.foreground} />
            </TouchableOpacity>
          </View>

          {/* Mode switcher */}
          {scans.length > 0 && (
            <View className="flex-row gap-2">
              {(["list", "compare", "trend"] as const).map((m) => (
                <TouchableOpacity
                  key={m}
                  onPress={() => {
                    setMode(m);
                    setCompareSelected([]);
                  }}
                  className="flex-1 rounded-xl py-2 items-center border"
                  style={{
                    backgroundColor: mode === m ? colors.primary : "transparent",
                    borderColor: mode === m ? colors.primary : colors.border || "#e5e7eb",
                  }}
                >
                  <Text
                    className="text-xs font-semibold capitalize"
                    style={{ color: mode === m ? colors.background : colors.foreground }}
                  >
                    {m === "compare" ? "Compare" : m === "trend" ? "Trend" : "List"}
                  </Text>
                </TouchableOpacity>
              ))}
            </View>
          )}

          {/* Compare instructions */}
          {mode === "compare" && (
            <View className="bg-primary/10 rounded-xl p-3 border border-primary/20">
              <Text className="text-xs text-primary text-center">
                {compareSelected.length === 0
                  ? "Tap any 2 scans below to compare them"
                  : compareSelected.length === 1
                  ? "Now tap a second scan to compare"
                  : "Comparing 2 scans — scroll up to see results"}
              </Text>
            </View>
          )}

          {/* Trend chart */}
          {mode === "trend" && <TrendChart />}

          {/* Compare panel */}
          {mode === "compare" && compareSelected.length === 2 && <ComparePanel />}

          {/* Scans list */}
          {scans.length > 0 ? (
            <View>
              {scans.map((scan) => (
                <ScanItem key={scan.id} scan={scan} />
              ))}
            </View>
          ) : (
            <View className="flex-1 items-center justify-center gap-4 py-12">
              <MaterialIcons name="history" size={48} color={colors.muted} />
              <Text className="text-base font-medium text-foreground">No scans yet</Text>
              <Text className="text-sm text-muted text-center">
                Start your first skin scan to begin tracking your progress
              </Text>
              <TouchableOpacity
                onPress={() => router.push("../scan")}
                className="bg-primary rounded-xl px-6 py-3 mt-4"
              >
                <Text className="text-base font-semibold text-background">Take First Scan</Text>
              </TouchableOpacity>
            </View>
          )}
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}
