import { useState } from "react";
import { ScrollView, Text, View, TouchableOpacity, TextInput, Alert, Switch } from "react-native";
import { useRouter, useLocalSearchParams } from "expo-router";
import { ScreenContainer } from "@/components/screen-container";
import { MaterialIcons } from "@expo/vector-icons";
import { useColors } from "@/hooks/use-colors";
import { useSkinContext } from "@/lib/skin-context";
import { DailyRoutine, RoutineProduct } from "@/lib/types";

const PRODUCT_TEMPLATES: RoutineProduct[] = [
  { id: "t1", name: "Gentle Cleanser", brand: "CeraVe", category: "cleanser", instructions: "Massage onto wet face for 30 seconds, rinse thoroughly", estimatedTime: 2 },
  { id: "t2", name: "Hydrating Toner", brand: "Neutrogena", category: "toner", instructions: "Apply to cotton pad and sweep across face", estimatedTime: 1 },
  { id: "t3", name: "Niacinamide Serum", brand: "The Ordinary", category: "serum", instructions: "Apply 2–3 drops, pat gently into skin", estimatedTime: 2 },
  { id: "t4", name: "Moisturiser", brand: "Nivea", category: "moisturizer", instructions: "Apply a pea-sized amount in upward circular motions", estimatedTime: 2 },
  { id: "t5", name: "Sunscreen SPF 50+", brand: "Neutrogena", category: "sunscreen", instructions: "Apply generously 15 mins before sun exposure. Reapply every 2 hours", estimatedTime: 2 },
  { id: "t6", name: "Retinol Treatment", brand: "Olay", category: "treatment", instructions: "Apply small amount to dry skin, avoid eye area", estimatedTime: 2 },
  { id: "t7", name: "Sheet Mask", brand: "Garnier", category: "mask", instructions: "Leave on for 15–20 minutes, pat in remaining essence", estimatedTime: 20 },
  { id: "t8", name: "Eye Cream", brand: "Olay", category: "other", instructions: "Dab gently around orbital bone with ring finger", estimatedTime: 1 },
];

const CATEGORY_ICONS: Record<string, string> = {
  cleanser: "bubble-chart",
  toner: "water-drop",
  serum: "science",
  moisturizer: "opacity",
  sunscreen: "wb-sunny",
  mask: "spa",
  treatment: "healing",
  other: "category",
};

export default function RoutineEditorScreen() {
  const router = useRouter();
  const colors = useColors();
  const { type, id } = useLocalSearchParams();
  const { addRoutine, routines } = useSkinContext();

  const routineType = (type as "morning" | "night") || "morning";
  const existingRoutine = id ? routines.find((r) => r.id === id) : null;

  const [selectedProducts, setSelectedProducts] = useState<RoutineProduct[]>(
    existingRoutine?.products || []
  );
  const [reminderEnabled, setReminderEnabled] = useState(existingRoutine?.reminderEnabled ?? true);
  const [reminderTime, setReminderTime] = useState(
    existingRoutine?.reminderTime || (routineType === "morning" ? "07:00" : "21:30")
  );
  const [showProductPicker, setShowProductPicker] = useState(false);
  const [isSaving, setIsSaving] = useState(false);

  const toggleProduct = (product: RoutineProduct) => {
    const exists = selectedProducts.find((p) => p.id === product.id);
    if (exists) {
      setSelectedProducts(selectedProducts.filter((p) => p.id !== product.id));
    } else {
      setSelectedProducts([...selectedProducts, product]);
    }
  };

  const moveProduct = (index: number, direction: "up" | "down") => {
    const newList = [...selectedProducts];
    const targetIndex = direction === "up" ? index - 1 : index + 1;
    if (targetIndex < 0 || targetIndex >= newList.length) return;
    [newList[index], newList[targetIndex]] = [newList[targetIndex], newList[index]];
    setSelectedProducts(newList);
  };

  const removeProduct = (productId: string) => {
    setSelectedProducts(selectedProducts.filter((p) => p.id !== productId));
  };

  const totalTime = selectedProducts.reduce((sum, p) => sum + p.estimatedTime, 0);

  const handleSave = async () => {
    if (selectedProducts.length === 0) {
      Alert.alert("Add Products", "Please add at least one product to your routine.");
      return;
    }
    setIsSaving(true);
    const routine: DailyRoutine = {
      id: existingRoutine?.id || Date.now().toString(),
      type: routineType,
      products: selectedProducts,
      reminderEnabled,
      reminderTime: reminderEnabled ? reminderTime : undefined,
    };
    await addRoutine(routine);
    setIsSaving(false);
    Alert.alert("Saved!", `Your ${routineType} routine has been saved.`, [
      { text: "OK", onPress: () => router.back() },
    ]);
  };

  return (
    <ScreenContainer className="p-4">
      <ScrollView contentContainerStyle={{ flexGrow: 1 }} showsVerticalScrollIndicator={false}>
        <View className="gap-6 pb-8">
          {/* Header */}
          <View className="flex-row justify-between items-center mt-2">
            <View>
              <Text className="text-3xl font-bold text-foreground">
                {id ? "Edit" : "Create"} Routine
              </Text>
              <Text className="text-sm text-muted mt-1 capitalize">
                {routineType} routine • {totalTime} min total
              </Text>
            </View>
            <TouchableOpacity onPress={() => router.back()}>
              <MaterialIcons name="close" size={28} color={colors.foreground} />
            </TouchableOpacity>
          </View>

          {/* Selected Products */}
          <View>
            <View className="flex-row justify-between items-center mb-3">
              <Text className="text-base font-semibold text-foreground">
                Your Products ({selectedProducts.length})
              </Text>
              <TouchableOpacity
                onPress={() => setShowProductPicker(!showProductPicker)}
                className="flex-row items-center gap-1 bg-primary rounded-lg px-3 py-2"
              >
                <MaterialIcons name="add" size={16} color={colors.background} />
                <Text className="text-xs font-semibold text-background">Add</Text>
              </TouchableOpacity>
            </View>

            {selectedProducts.length === 0 ? (
              <View className="bg-surface rounded-2xl p-6 border border-dashed border-border items-center gap-2">
                <MaterialIcons name="add-circle-outline" size={36} color={colors.muted} />
                <Text className="text-sm text-muted text-center">
                  Tap "Add" to pick products for your routine
                </Text>
              </View>
            ) : (
              <View className="gap-2">
                {selectedProducts.map((product, index) => (
                  <View key={product.id} className="bg-surface rounded-xl p-3 border border-border">
                    <View className="flex-row items-center gap-3">
                      <View className="w-10 h-10 rounded-full bg-primary/10 items-center justify-center">
                        <MaterialIcons
                          name={(CATEGORY_ICONS[product.category] || "category") as any}
                          size={18}
                          color={colors.primary}
                        />
                      </View>
                      <View className="flex-1">
                        <Text className="text-sm font-medium text-foreground">{product.name}</Text>
                        <Text className="text-xs text-muted">
                          {product.brand} • {product.estimatedTime} min
                        </Text>
                      </View>
                      <View className="flex-row items-center gap-1">
                        <TouchableOpacity
                          onPress={() => moveProduct(index, "up")}
                          disabled={index === 0}
                          style={{ opacity: index === 0 ? 0.3 : 1 }}
                        >
                          <MaterialIcons name="keyboard-arrow-up" size={20} color={colors.muted} />
                        </TouchableOpacity>
                        <TouchableOpacity
                          onPress={() => moveProduct(index, "down")}
                          disabled={index === selectedProducts.length - 1}
                          style={{ opacity: index === selectedProducts.length - 1 ? 0.3 : 1 }}
                        >
                          <MaterialIcons name="keyboard-arrow-down" size={20} color={colors.muted} />
                        </TouchableOpacity>
                        <TouchableOpacity onPress={() => removeProduct(product.id)}>
                          <MaterialIcons name="close" size={20} color={colors.destructive || "#ef4444"} />
                        </TouchableOpacity>
                      </View>
                    </View>
                    <Text className="text-xs text-muted mt-2 ml-13">{product.instructions}</Text>
                  </View>
                ))}
              </View>
            )}
          </View>

          {/* Product Picker */}
          {showProductPicker && (
            <View className="bg-surface rounded-2xl border border-border p-4 gap-3">
              <Text className="text-sm font-semibold text-foreground">Choose Products</Text>
              {PRODUCT_TEMPLATES.map((product) => {
                const isSelected = !!selectedProducts.find((p) => p.id === product.id);
                return (
                  <TouchableOpacity
                    key={product.id}
                    onPress={() => toggleProduct(product)}
                    className="flex-row items-center gap-3 py-2"
                  >
                    <View
                      className="w-6 h-6 rounded-full border-2 items-center justify-center"
                      style={{
                        borderColor: isSelected ? colors.primary : colors.border || "#e5e7eb",
                        backgroundColor: isSelected ? colors.primary : "transparent",
                      }}
                    >
                      {isSelected && <MaterialIcons name="check" size={14} color={colors.background} />}
                    </View>
                    <View className="flex-1">
                      <Text className="text-sm font-medium text-foreground">{product.name}</Text>
                      <Text className="text-xs text-muted">
                        {product.brand} • {product.category} • {product.estimatedTime} min
                      </Text>
                    </View>
                  </TouchableOpacity>
                );
              })}
            </View>
          )}

          {/* Reminder */}
          <View className="bg-surface rounded-2xl p-4 border border-border gap-4">
            <Text className="text-base font-semibold text-foreground">Reminder</Text>
            <View className="flex-row justify-between items-center">
              <View className="flex-row items-center gap-2">
                <MaterialIcons name="notifications" size={20} color={colors.primary} />
                <Text className="text-sm text-foreground">Enable Reminder</Text>
              </View>
              <Switch
                value={reminderEnabled}
                onValueChange={setReminderEnabled}
                trackColor={{ false: "#767577", true: colors.primary }}
                thumbColor={reminderEnabled ? "#fff" : "#f4f3f4"}
              />
            </View>
            {reminderEnabled && (
              <View className="flex-row items-center gap-3">
                <MaterialIcons name="access-time" size={18} color={colors.muted} />
                <Text className="text-sm text-muted">Time:</Text>
                <TextInput
                  value={reminderTime}
                  onChangeText={setReminderTime}
                  placeholder="HH:MM"
                  placeholderTextColor={colors.muted}
                  className="bg-background border border-border rounded-lg px-3 py-2 text-sm text-foreground flex-1"
                  keyboardType="numbers-and-punctuation"
                />
              </View>
            )}
          </View>

          {/* Save Button */}
          <TouchableOpacity
            onPress={handleSave}
            disabled={isSaving}
            className="bg-primary rounded-xl py-4 items-center mt-2"
            style={{ opacity: isSaving ? 0.6 : 1 }}
          >
            {isSaving ? (
              <Text className="text-base font-semibold text-background">Saving...</Text>
            ) : (
              <View className="flex-row items-center gap-2">
                <MaterialIcons name="check" size={20} color={colors.background} />
                <Text className="text-base font-semibold text-background">
                  Save {routineType === "morning" ? "Morning" : "Night"} Routine
                </Text>
              </View>
            )}
          </TouchableOpacity>
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}
