import { ScrollView, Text, View, TouchableOpacity } from "react-native";
import { useRouter, useLocalSearchParams } from "expo-router";
import { ScreenContainer } from "@/components/screen-container";
import { useColors } from "@/hooks/use-colors";
import { useSkinContext } from "@/lib/skin-context";
import { MaterialIcons } from "@expo/vector-icons";

export default function ScanResultsScreen() {
  const router = useRouter();
  const colors = useColors();
  const { getLatestScan, scans } = useSkinContext();
  const { id } = useLocalSearchParams<{ id: string }>();

  // Support opening from history with ?id=, or default to latest
  const scan = id ? scans.find((s) => s.id === id) : getLatestScan();

  if (!scan) {
    return (
      <ScreenContainer className="p-4">
        <View className="flex-1 items-center justify-center gap-4">
          <MaterialIcons name="image-search" size={48} color={colors.muted} />
          <Text className="text-lg text-muted">No scan results available</Text>
          <TouchableOpacity onPress={() => router.back()}
            className="rounded-xl px-6 py-3" style={{ backgroundColor: colors.primary }}>
            <Text className="text-base font-semibold" style={{ color: colors.surface }}>Go Back</Text>
          </TouchableOpacity>
        </View>
      </ScreenContainer>
    );
  }

  const getMetricColor = (value: number, isInverted = false) => {
    const good = isInverted ? value < 40 : value > 60;
    const ok = isInverted ? value < 60 : value > 40;
    if (good) return colors.success;
    if (ok) return colors.warning;
    return colors.error;
  };

  const MetricBar = ({ label, value, unit = "", isInverted = false }: {
    label: string; value: number; unit?: string; isInverted?: boolean;
  }) => {
    const c = getMetricColor(value, isInverted);
    return (
      <View className="rounded-2xl p-4 border mb-3"
        style={{ backgroundColor: colors.surface, borderColor: colors.border }}>
        <View className="flex-row justify-between items-center mb-2">
          <Text className="text-sm font-medium text-muted">{label}</Text>
          <View className="rounded-full px-3 py-1" style={{ backgroundColor: `${c}20` }}>
            <Text className="text-xs font-semibold" style={{ color: c }}>{value}{unit}</Text>
          </View>
        </View>
        <View className="w-full h-2 rounded-full overflow-hidden" style={{ backgroundColor: colors.border }}>
          <View className="h-full rounded-full" style={{ width: `${value}%`, backgroundColor: c }} />
        </View>
      </View>
    );
  };

  const scoreColor = scan.skinScore >= 80 ? colors.success : scan.skinScore >= 60 ? colors.warning : colors.error;

  return (
    <ScreenContainer className="p-4">
      <ScrollView contentContainerStyle={{ flexGrow: 1 }} showsVerticalScrollIndicator={false}>
        <View className="gap-6 pb-8">
          {/* Header */}
          <View className="flex-row justify-between items-center mt-2">
            <View>
              <Text className="text-3xl font-bold text-foreground">Scan Results</Text>
              <Text className="text-sm text-muted mt-1">
                {new Date(scan.timestamp).toLocaleDateString("en-NG", {
                  month: "long", day: "numeric", year: "numeric",
                })}
              </Text>
            </View>
            <TouchableOpacity onPress={() => router.back()}>
              <MaterialIcons name="close" size={28} color={colors.foreground} />
            </TouchableOpacity>
          </View>

          {/* Score */}
          <View className="rounded-3xl p-6 border items-center gap-2"
            style={{ backgroundColor: colors.surface, borderColor: `${scoreColor}40` }}>
            <Text className="text-sm font-medium text-muted">Overall Skin Score</Text>
            <Text className="text-7xl font-bold" style={{ color: scoreColor }}>
              {Math.round(scan.skinScore)}
            </Text>
            <Text className="text-xs text-muted">/100</Text>
            <View className="rounded-full px-4 py-1 mt-1" style={{ backgroundColor: `${scoreColor}18` }}>
              <Text className="text-sm font-semibold capitalize" style={{ color: scoreColor }}>
                {scan.skinScore >= 80 ? "Excellent" : scan.skinScore >= 60 ? "Good" : "Needs Attention"} · {scan.skinType} skin
              </Text>
            </View>
            <Text className="text-sm text-muted text-center mt-2 leading-relaxed">
              {scan.conditionSummary}
            </Text>
          </View>

          {/* Metrics */}
          <View>
            <Text className="text-lg font-semibold text-foreground mb-3">Skin Metrics</Text>
            <MetricBar label="Hydration Level" value={scan.metrics.hydration} unit="%" />
            <MetricBar label="Pore Size" value={scan.metrics.poreSize} isInverted />
            <MetricBar label="Dark Spots" value={Math.min(scan.metrics.darkSpots * 10, 100)} isInverted />
            <MetricBar label="Redness Level" value={scan.metrics.redness} isInverted />
            <MetricBar label="Texture Quality" value={scan.metrics.texture} unit="%" />
          </View>

          {/* Recommendations */}
          <View>
            <Text className="text-lg font-semibold text-foreground mb-3">Recommendations</Text>
            <View className="gap-2">
              {scan.recommendations.map((rec, i) => (
                <View key={i} className="rounded-2xl p-4 border flex-row gap-3"
                  style={{ backgroundColor: colors.surface, borderColor: colors.border }}>
                  <MaterialIcons name="check-circle" size={20} color={colors.success} />
                  <Text className="flex-1 text-sm text-foreground leading-relaxed">{rec}</Text>
                </View>
              ))}
            </View>
          </View>

          {/* Actions */}
          <View className="gap-3">
            <TouchableOpacity onPress={() => router.push("../routine")}
              className="rounded-xl py-4 items-center" style={{ backgroundColor: colors.primary }}>
              <Text className="text-base font-semibold" style={{ color: colors.surface }}>
                Build My Routine
              </Text>
            </TouchableOpacity>
            <TouchableOpacity onPress={() => router.push("/(tabs)")}
              className="rounded-xl py-4 items-center border"
              style={{ backgroundColor: colors.surface, borderColor: colors.border }}>
              <Text className="text-base font-semibold text-foreground">Back to Home</Text>
            </TouchableOpacity>
          </View>
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}
