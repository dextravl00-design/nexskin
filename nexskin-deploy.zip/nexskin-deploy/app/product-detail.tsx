import { ScrollView, Text, View, TouchableOpacity, Linking } from "react-native";
import { useRouter, useLocalSearchParams } from "expo-router";
import { ScreenContainer } from "@/components/screen-container";
import { useColors } from "@/hooks/use-colors";
import { MaterialIcons } from "@expo/vector-icons";

const PRODUCTS: Record<string, any> = {
  "1": { name:"Niacinamide 10% + Zinc 1%", brand:"The Ordinary", price:8500, rating:4.9, reviews:12400, image:"🧪", tiktokHook:"\"This $5 serum cleared my skin in 2 weeks\"", description:"The most talked-about serum on TikTok. Minimises pores, controls oil and fades dark spots. A cult favourite for oily and acne-prone skin.", howToUse:"Apply 2–3 drops after cleansing, before moisturiser. Use AM & PM.", where:"Jumia NG, Konga, Health Plus", link:"https://www.jumia.com.ng", ingredients:[{name:"Niacinamide 10%",benefit:"Minimises pores, fades dark spots",isIrritant:false},{name:"Zinc PCA 1%",benefit:"Controls sebum and oiliness",isIrritant:false},{name:"Tamarind Seed Extract",benefit:"Lightweight hydration",isIrritant:false},{name:"Pentylene Glycol",benefit:"Skin conditioning",isIrritant:false}], skinTypes:["oily","combination","normal"] },
  "2": { name:"AHA 30% + BHA 2% Peeling Solution", brand:"The Ordinary", price:12000, rating:4.7, reviews:8900, image:"🩸", tiktokHook:"\"The red mask that transforms your skin overnight\"", description:"The viral red peel that exfoliates dead skin, fades hyperpigmentation and smooths texture. Use ONCE per week max.", howToUse:"Apply to dry face, leave 10 minutes max, rinse thoroughly. Use at night only. Patch test first.", where:"Jumia NG, Konga", link:"https://www.jumia.com.ng", ingredients:[{name:"Glycolic Acid 30%",benefit:"Removes dead skin cells",isIrritant:true},{name:"Salicylic Acid 2%",benefit:"Unclogs pores",isIrritant:true},{name:"Hyaluronic Acid",benefit:"Hydration during exfoliation",isIrritant:false},{name:"Tartaric Acid",benefit:"Exfoliation support",isIrritant:false}], skinTypes:["oily","combination","normal"] },
  "3": { name:"Hyaluronic Acid 2% + B5", brand:"The Ordinary", price:9000, rating:4.8, reviews:10200, image:"💧", tiktokHook:"\"Plump skin in 3 days — no filter\"", description:"The hydration serum everyone on TikTok swears by. Draws moisture deep into the skin for a plumped, dewy look.", howToUse:"Apply to damp skin before moisturiser. Works best layered under SPF in the morning.", where:"Jumia NG, Konga, Health Plus", link:"https://www.jumia.com.ng", ingredients:[{name:"Hyaluronic Acid 2%",benefit:"Deep multi-level hydration",isIrritant:false},{name:"Vitamin B5",benefit:"Skin healing and softening",isIrritant:false},{name:"Glycerin",benefit:"Moisture retention",isIrritant:false}], skinTypes:["dry","sensitive","normal","combination"] },
  "4": { name:"Retinol 0.5% in Squalane", brand:"The Ordinary", price:11000, rating:4.6, reviews:7300, image:"🌙", tiktokHook:"\"Start retinol in your 20s — your 40-year-old self will thank you\"", description:"The entry-level retinol TikTok derms always recommend. Speeds cell turnover, smooths fine lines and fades marks over time.", howToUse:"Use at night only, 2–3x per week to start. Always wear SPF the next morning.", where:"Jumia NG, Konga", link:"https://www.jumia.com.ng", ingredients:[{name:"Retinol 0.5%",benefit:"Cell turnover, anti-aging",isIrritant:true},{name:"Squalane",benefit:"Moisturises without clogging pores",isIrritant:false}], skinTypes:["normal","combination","dry"] },
  "5": { name:"Glycolic Acid 7% Toning Solution", brand:"The Ordinary", price:9500, rating:4.7, reviews:9100, image:"✨", tiktokHook:"\"This toner got rid of my bumpy skin texture in 1 week\"", description:"TikTok's favourite exfoliating toner. Smooths skin texture, brightens and fades hyperpigmentation with regular use.", howToUse:"Swipe over face with a cotton pad at night. Do not mix with Vitamin C or retinol the same night.", where:"Jumia NG, Konga", link:"https://www.jumia.com.ng", ingredients:[{name:"Glycolic Acid 7%",benefit:"Exfoliation and brightening",isIrritant:true},{name:"Ginseng Root Extract",benefit:"Antioxidant",isIrritant:false},{name:"Tasmanian Pepperberry",benefit:"Reduces irritation from AHA",isIrritant:false}], skinTypes:["oily","combination","normal"] },
  "6": { name:"BHA Blackhead Power Liquid", brand:"COSRX", price:14000, rating:4.8, reviews:11500, image:"🫧", tiktokHook:"\"POV: You finally found something that actually unclogs your pores\"", description:"K-beauty viral favourite. Willow bark BHA gently dissolves blackheads, tightens pores and calms irritated skin.", howToUse:"Apply with hands or cotton pad after cleansing. Leave on — do not rinse. Use at night.", where:"Jumia NG, TikTok Shop, Konga", link:"https://www.jumia.com.ng", ingredients:[{name:"Willow Bark Water 84%",benefit:"Natural BHA — pore cleansing",isIrritant:false},{name:"Butylene Glycol",benefit:"Hydration",isIrritant:false},{name:"Sodium Hyaluronate",benefit:"Deep hydration",isIrritant:false}], skinTypes:["oily","combination"] },
  "7": { name:"Snail Mucin 96% Power Essence", brand:"COSRX", price:18000, rating:4.9, reviews:15600, image:"🐌", tiktokHook:"\"I put snail juice on my face and I've never looked better\"", description:"The most viral K-beauty product ever. Snail mucin repairs the skin barrier, deeply hydrates and calms redness. Works for every skin type.", howToUse:"Pat into skin after toner. Can be used AM & PM. Layer generously — it absorbs quickly.", where:"Jumia NG, TikTok Shop, Konga", link:"https://www.jumia.com.ng", ingredients:[{name:"Snail Secretion Filtrate 96%",benefit:"Barrier repair, hydration, healing",isIrritant:false},{name:"Sodium Hyaluronate",benefit:"Hydration",isIrritant:false},{name:"Betaine",benefit:"Skin conditioning",isIrritant:false}], skinTypes:["all"] },
  "8": { name:"Moisturising Cream", brand:"CeraVe", price:16000, rating:4.9, reviews:21000, image:"🫙", tiktokHook:"\"Dermatologists recommend this every single time — and they're right\"", description:"TikTok's most recommended moisturiser. Ceramides repair your skin barrier while hyaluronic acid locks in moisture all day.", howToUse:"Apply as the last step in your routine AM & PM. Safe for face and body.", where:"Health Plus, Pharmplus, Jumia NG", link:"https://www.jumia.com.ng", ingredients:[{name:"Ceramides 1, 3, 6-II",benefit:"Restores skin barrier",isIrritant:false},{name:"Hyaluronic Acid",benefit:"Long-lasting hydration",isIrritant:false},{name:"Niacinamide",benefit:"Calms and brightens",isIrritant:false},{name:"MVE Technology",benefit:"24-hour moisture release",isIrritant:false}], skinTypes:["dry","sensitive","normal"] },
  "9": { name:"Watermelon Glow Sleeping Mask", brand:"Glow Recipe", price:32000, rating:4.8, reviews:6700, image:"🍉", tiktokHook:"\"Wake up with glass skin — this overnight mask changed everything\"", description:"TikTok's favourite overnight mask. Watermelon extract, hyaluronic acid and AHA gently exfoliate and plump skin while you sleep.", howToUse:"Apply as the last step at night, 2–3x per week. Rinse off in the morning.", where:"Sephora online, Jumia NG", link:"https://www.jumia.com.ng", ingredients:[{name:"Watermelon Extract",benefit:"Hydration and brightening",isIrritant:false},{name:"Hyaluronic Acid",benefit:"Overnight plumping",isIrritant:false},{name:"AHA",benefit:"Gentle overnight exfoliation",isIrritant:true},{name:"Peony Extract",benefit:"Soothing",isIrritant:false}], skinTypes:["all"] },
  "10": { name:"Hydrating Facial Cleanser", brand:"CeraVe", price:13500, rating:4.9, reviews:18900, image:"🧴", tiktokHook:"\"The cleanser that doesn't strip your skin — game changer\"", description:"The non-stripping cleanser that TikTok derms always recommend. Gentle enough for sensitive skin, cleans without destroying your moisture barrier.", howToUse:"Massage onto wet face for 30–60 seconds. Rinse with lukewarm water AM & PM.", where:"Health Plus, Pharmplus, Jumia NG", link:"https://www.jumia.com.ng", ingredients:[{name:"Ceramides",benefit:"Barrier protection while cleansing",isIrritant:false},{name:"Glycerin",benefit:"Moisture retention",isIrritant:false},{name:"Hyaluronic Acid",benefit:"Hydration",isIrritant:false}], skinTypes:["dry","sensitive","normal"] },
  "11": { name:"Low pH Good Morning Gel Cleanser", brand:"COSRX", price:12500, rating:4.8, reviews:9400, image:"🫗", tiktokHook:"\"The K-beauty cleanser your skin needs to stay balanced\"", description:"Viral K-beauty cleanser with a skin-friendly pH that respects your barrier. Gentle, soothing and perfect before toners and serums.", howToUse:"Apply to wet face, gently massage, rinse thoroughly. Use AM & PM.", where:"Jumia NG, TikTok Shop", link:"https://www.jumia.com.ng", ingredients:[{name:"Purified Water",benefit:"pH 5.0 base",isIrritant:false},{name:"Apple Water",benefit:"Soothing and brightening",isIrritant:false},{name:"Tea Tree Extract",benefit:"Antibacterial",isIrritant:false}], skinTypes:["oily","combination","sensitive"] },
  "12": { name:"Tone-up Sunscreen SPF50+ PA++++", brand:"Beauty of Joseon", price:15000, rating:4.9, reviews:13200, image:"🌸", tiktokHook:"\"This Korean SPF gives you a natural blur filter — zero white cast\"", description:"TikTok's most viral K-beauty SPF. Protects and gives a soft, blurred finish. Works beautifully on melanin-rich skin with absolutely no white cast.", howToUse:"Apply as final AM step before makeup. 2 finger-lengths for full face coverage. Reapply every 2 hours.", where:"Jumia NG, TikTok Shop, Konga", link:"https://www.jumia.com.ng", ingredients:[{name:"Niacinamide",benefit:"Brightening and pore-minimising",isIrritant:false},{name:"Rice Extract",benefit:"Soothing and skin-evening",isIrritant:false},{name:"SPF 50+ PA++++",benefit:"Broad-spectrum UV protection",isIrritant:false}], skinTypes:["all"] },
  "13": { name:"Ultra Light Daily UV Defense SPF 50", brand:"Kiehl's", price:38000, rating:4.8, reviews:5200, image:"☀️", tiktokHook:"\"SPF is the best anti-aging product — derms don't lie\"", description:"The lightweight SPF that TikTok skinfluencers call their holy grail. Zero white cast, non-greasy — built for daily use in hot climates like Nigeria.", howToUse:"Apply generously as the final step every morning. Reapply every 2 hours when outdoors.", where:"Sephora online, Jumia NG", link:"https://www.jumia.com.ng", ingredients:[{name:"Mexoryl SX",benefit:"UVA protection",isIrritant:false},{name:"Anthelios Mineral Filters",benefit:"Broad-spectrum SPF",isIrritant:false},{name:"Vitamin E",benefit:"Antioxidant protection",isIrritant:false}], skinTypes:["all"] },
  "14": { name:"Vitamin C Suspension 23% + HA 2%", brand:"The Ordinary", price:10500, rating:4.6, reviews:7800, image:"🍋", tiktokHook:"\"Budget Vitamin C that actually works — stop overpaying\"", description:"The budget-friendly Vitamin C TikTok recommends. Brightens, fades marks and protects from free radicals at a fraction of the price.", howToUse:"Apply at night only on clean, dry skin before moisturiser. Can tingle slightly — that is normal.", where:"Jumia NG, Konga", link:"https://www.jumia.com.ng", ingredients:[{name:"Ascorbic Acid 23%",benefit:"Brightening, antioxidant",isIrritant:true},{name:"Hyaluronic Acid 2%",benefit:"Prevents dryness from high-dose Vit C",isIrritant:false}], skinTypes:["normal","combination","oily"] },
  "15": { name:"2% BHA Liquid Exfoliant", brand:"Paula's Choice", price:25000, rating:4.8, reviews:8300, image:"💚", tiktokHook:"\"Paula's Choice BHA — the one TikTok derms put on their own face\"", description:"The professional-grade BHA exfoliant that unclogs pores, smooths texture and reduces redness. A TikTok derm staple for clear skin.", howToUse:"Apply a small amount to a cotton pad and sweep across face after cleansing. Use at night.", where:"Sephora online, Jumia NG", link:"https://www.jumia.com.ng", ingredients:[{name:"Salicylic Acid 2%",benefit:"Unclogs pores, smooths texture",isIrritant:true},{name:"Green Tea Extract",benefit:"Antioxidant, calming",isIrritant:false},{name:"Methylpropanediol",benefit:"Enhances ingredient penetration",isIrritant:false}], skinTypes:["oily","combination"] },
};

export default function ProductDetailScreen() {
  const router = useRouter();
  const colors = useColors();
  const { id } = useLocalSearchParams<{ id: string }>();
  const product = PRODUCTS[id ?? "1"];

  if (!product) {
    return (
      <ScreenContainer className="p-4">
        <View className="flex-1 items-center justify-center gap-4">
          <MaterialIcons name="search-off" size={48} color={colors.muted} />
          <Text className="text-base text-muted">Product not found</Text>
          <TouchableOpacity onPress={() => router.back()} className="rounded-xl px-6 py-3" style={{ backgroundColor: colors.primary }}>
            <Text className="text-base font-semibold" style={{ color: colors.surface }}>Go Back</Text>
          </TouchableOpacity>
        </View>
      </ScreenContainer>
    );
  }

  const irritants = product.ingredients.filter((i: any) => i.isIrritant);
  const safeIngredients = product.ingredients.filter((i: any) => !i.isIrritant);

  return (
    <ScreenContainer className="p-4">
      <ScrollView contentContainerStyle={{ flexGrow: 1 }} showsVerticalScrollIndicator={false}>
        <View className="gap-5 pb-8">
          <View className="flex-row justify-between items-center mt-2">
            <TouchableOpacity onPress={() => router.back()}>
              <MaterialIcons name="arrow-back" size={28} color={colors.foreground} />
            </TouchableOpacity>
            <Text className="text-sm font-semibold text-foreground">Product Detail</Text>
            <View style={{ width: 28 }} />
          </View>

          <View className="rounded-2xl p-5 border items-center gap-3" style={{ backgroundColor: colors.surface, borderColor: colors.border }}>
            <View className="w-24 h-24 rounded-2xl items-center justify-center" style={{ backgroundColor: `${colors.primary}15` }}>
              <Text style={{ fontSize: 44 }}>{product.image}</Text>
            </View>
            <Text className="text-xl font-bold text-foreground text-center">{product.name}</Text>
            <Text className="text-sm font-semibold" style={{ color: colors.primary }}>{product.brand}</Text>
            <View className="flex-row items-center gap-2">
              <MaterialIcons name="star" size={14} color={colors.warning} />
              <Text className="text-sm font-semibold text-foreground">{product.rating}</Text>
              <Text className="text-xs text-muted">({product.reviews.toLocaleString()} reviews)</Text>
            </View>
            <Text className="text-2xl font-bold" style={{ color: colors.primary }}>
              {`\u20a6${product.price.toLocaleString("en-NG")}`}
            </Text>
          </View>

          <View className="rounded-2xl p-4 border flex-row gap-3 items-start" style={{ backgroundColor: `${colors.primary}10`, borderColor: `${colors.primary}25` }}>
            <Text style={{ fontSize: 18 }}>📱</Text>
            <Text className="text-sm flex-1 leading-relaxed" style={{ color: colors.primary, fontStyle: "italic" }}>{product.tiktokHook}</Text>
          </View>

          <View className="rounded-2xl p-4 border" style={{ backgroundColor: colors.surface, borderColor: colors.border }}>
            <Text className="text-sm font-semibold text-foreground mb-2">About</Text>
            <Text className="text-sm text-muted leading-relaxed">{product.description}</Text>
          </View>

          <View className="rounded-2xl p-4 border" style={{ backgroundColor: colors.surface, borderColor: colors.border }}>
            <View className="flex-row items-center gap-2 mb-3">
              <MaterialIcons name="fact-check" size={16} color={colors.primary} />
              <Text className="text-sm font-semibold text-foreground">How to Use</Text>
            </View>
            <Text className="text-sm text-muted leading-relaxed">{product.howToUse}</Text>
          </View>

          <View className="rounded-2xl p-4 border" style={{ backgroundColor: colors.surface, borderColor: colors.border }}>
            <Text className="text-sm font-semibold text-foreground mb-3">Key Ingredients</Text>
            {product.ingredients.map((ing: any, i: number) => (
              <View key={i} className="flex-row items-start gap-3 mb-2">
                <View className="w-2 h-2 rounded-full mt-1.5 flex-shrink-0" style={{ backgroundColor: ing.isIrritant ? colors.warning : colors.success }} />
                <View className="flex-1">
                  <Text className="text-sm font-medium text-foreground">
                    {ing.name}{ing.isIrritant ? " ⚠" : ""}
                  </Text>
                  <Text className="text-xs text-muted">{ing.benefit}</Text>
                </View>
              </View>
            ))}
            {irritants.length > 0 && (
              <View className="mt-3 rounded-xl p-3 flex-row gap-2 items-start" style={{ backgroundColor: `${colors.warning}15` }}>
                <MaterialIcons name="warning" size={16} color={colors.warning} />
                <Text className="text-xs flex-1 leading-relaxed" style={{ color: colors.warning }}>
                  Contains active acids/retinol — patch test recommended. Avoid if pregnant without consulting a doctor.
                </Text>
              </View>
            )}
          </View>

          <View className="rounded-2xl p-4 border" style={{ backgroundColor: colors.surface, borderColor: colors.border }}>
            <View className="flex-row items-center gap-2 mb-3">
              <MaterialIcons name="store" size={16} color={colors.primary} />
              <Text className="text-sm font-semibold text-foreground">Where to Buy in Nigeria</Text>
            </View>
            <Text className="text-sm text-muted mb-4">{product.where}</Text>
            <TouchableOpacity onPress={() => Linking.openURL(product.link)} className="rounded-xl py-4 items-center" style={{ backgroundColor: colors.primary }}>
              <View className="flex-row items-center gap-2">
                <MaterialIcons name="shopping-cart" size={18} color={colors.surface} />
                <Text className="text-base font-semibold" style={{ color: colors.surface }}>Shop on Jumia / Konga</Text>
              </View>
            </TouchableOpacity>
          </View>
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}
