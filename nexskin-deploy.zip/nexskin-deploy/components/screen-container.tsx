import { View, ViewProps } from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";

interface Props extends ViewProps {
  className?: string;
}

export function ScreenContainer({ children, className, style }: Props) {
  return (
    <View className="flex-1 bg-background">
      <SafeAreaView edges={["top", "left", "right"]} className="flex-1">
        <View className={`flex-1 ${className ?? ""}`} style={style}>
          {children}
        </View>
      </SafeAreaView>
    </View>
  );
}
