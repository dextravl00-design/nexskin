import { useTheme } from "@/lib/theme-provider";
export function useColors() {
  return useTheme().colors;
}
