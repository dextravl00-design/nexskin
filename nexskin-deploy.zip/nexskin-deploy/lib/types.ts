export interface SkinMetrics {
  hydration: number;
  poreSize: number;
  darkSpots: number;
  redness: number;
  texture: number;
}

export interface SkinScan {
  id: string;
  timestamp: number;
  imageUri: string;
  skinScore: number;
  skinType: "oily" | "dry" | "combination" | "sensitive" | "normal";
  metrics: SkinMetrics;
  recommendations: string[];
  conditionSummary: string;
}

export interface RoutineProduct {
  id: string;
  name: string;
  brand: string;
  category: "cleanser" | "toner" | "serum" | "moisturizer" | "sunscreen" | "mask" | "treatment" | "other";
  instructions: string;
  estimatedTime: number;
}

export interface DailyRoutine {
  id: string;
  type: "morning" | "night";
  products: RoutineProduct[];
  reminderTime?: string;
  reminderEnabled: boolean;
}

export interface WeeklyTrackingEntry {
  date: string;
  skinRating: number;
  notes: string;
}

export interface AppSettings {
  skinType: "oily" | "dry" | "combination" | "sensitive" | "normal";
  skinConcerns: string[];
  morningRoutineTime: string;
  nightRoutineTime: string;
  notificationsEnabled: boolean;
  darkMode: "auto" | "light" | "dark";
  name: string;
}
