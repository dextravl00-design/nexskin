export type ColorScheme = "light" | "dark";

export const Colors = {
  light: {
    primary: "#9333ea",
    background: "#fdf4ff",
    surface: "#ffffff",
    foreground: "#1a1a2e",
    muted: "#6b7280",
    border: "#e9d5ff",
    success: "#22c55e",
    warning: "#f59e0b",
    error: "#ef4444",
    tint: "#9333ea",
    tabIconDefault: "#6b7280",
    tabIconSelected: "#9333ea",
  },
  dark: {
    primary: "#c084fc",
    background: "#0f0a1a",
    surface: "#1a1030",
    foreground: "#f3e8ff",
    muted: "#9ca3af",
    border: "#3b2060",
    success: "#4ade80",
    warning: "#fbbf24",
    error: "#f87171",
    tint: "#c084fc",
    tabIconDefault: "#9ca3af",
    tabIconSelected: "#c084fc",
  },
};

export type ThemeColors = typeof Colors.light;
