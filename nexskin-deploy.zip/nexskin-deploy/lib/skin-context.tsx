import React, { createContext, useContext, useEffect, useState } from "react";
import { loadData, saveData } from "./storage";
import { SkinScan, DailyRoutine, WeeklyTrackingEntry, AppSettings } from "./types";

interface SkinContextType {
  scans: SkinScan[];
  addScan: (scan: SkinScan) => Promise<void>;
  getLatestScan: () => SkinScan | null;
  routines: DailyRoutine[];
  addRoutine: (routine: DailyRoutine) => Promise<void>;
  updateRoutine: (id: string, routine: DailyRoutine) => Promise<void>;
  deleteRoutine: (id: string) => Promise<void>;
  weeklyEntries: WeeklyTrackingEntry[];
  addWeeklyEntry: (entry: WeeklyTrackingEntry) => Promise<void>;
  settings: AppSettings;
  updateSettings: (s: AppSettings) => Promise<void>;
  isLoading: boolean;
}

const DEFAULT_SETTINGS: AppSettings = {
  skinType: "normal",
  skinConcerns: [],
  morningRoutineTime: "08:00",
  nightRoutineTime: "22:00",
  notificationsEnabled: true,
  darkMode: "auto",
  name: "",
};

const SkinContext = createContext<SkinContextType | undefined>(undefined);

export function SkinProvider({ children }: { children: React.ReactNode }) {
  const [scans, setScans] = useState<SkinScan[]>([]);
  const [routines, setRoutines] = useState<DailyRoutine[]>([]);
  const [weeklyEntries, setWeeklyEntries] = useState<WeeklyTrackingEntry[]>([]);
  const [settings, setSettings] = useState<AppSettings>(DEFAULT_SETTINGS);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    Promise.all([
      loadData<SkinScan[]>("nexskin_scans", []),
      loadData<DailyRoutine[]>("nexskin_routines", []),
      loadData<WeeklyTrackingEntry[]>("nexskin_weekly", []),
      loadData<AppSettings>("nexskin_settings", DEFAULT_SETTINGS),
    ]).then(([s, r, w, set]) => {
      setScans(s);
      setRoutines(r);
      setWeeklyEntries(w);
      setSettings(set);
      setIsLoading(false);
    });
  }, []);

  const addScan = async (scan: SkinScan) => {
    const updated = [scan, ...scans];
    setScans(updated);
    await saveData("nexskin_scans", updated);
  };

  const getLatestScan = () => (scans.length > 0 ? scans[0] : null);

  const addRoutine = async (routine: DailyRoutine) => {
    // Replace if same type exists, otherwise add
    const existing = routines.findIndex((r) => r.id === routine.id);
    const updated =
      existing >= 0
        ? routines.map((r) => (r.id === routine.id ? routine : r))
        : [...routines, routine];
    setRoutines(updated);
    await saveData("nexskin_routines", updated);
  };

  const updateRoutine = async (id: string, routine: DailyRoutine) => {
    const updated = routines.map((r) => (r.id === id ? routine : r));
    setRoutines(updated);
    await saveData("nexskin_routines", updated);
  };

  const deleteRoutine = async (id: string) => {
    const updated = routines.filter((r) => r.id !== id);
    setRoutines(updated);
    await saveData("nexskin_routines", updated);
  };

  const addWeeklyEntry = async (entry: WeeklyTrackingEntry) => {
    const updated = [entry, ...weeklyEntries.filter((e) => e.date !== entry.date)];
    setWeeklyEntries(updated);
    await saveData("nexskin_weekly", updated);
  };

  const updateSettings = async (s: AppSettings) => {
    setSettings(s);
    await saveData("nexskin_settings", s);
  };

  return (
    <SkinContext.Provider
      value={{
        scans, addScan, getLatestScan,
        routines, addRoutine, updateRoutine, deleteRoutine,
        weeklyEntries, addWeeklyEntry,
        settings, updateSettings,
        isLoading,
      }}
    >
      {children}
    </SkinContext.Provider>
  );
}

export function useSkinContext() {
  const ctx = useContext(SkinContext);
  if (!ctx) throw new Error("useSkinContext must be inside SkinProvider");
  return ctx;
}
