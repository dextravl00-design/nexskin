import React, { createContext, useContext, useEffect, useState } from "react";
import { supabase, Vendor, VendorProduct, Order } from "./supabase";
import { saveData, loadData } from "./storage";

interface VendorContextType {
  vendor: Vendor | null;
  products: VendorProduct[];
  orders: Order[];
  isLoading: boolean;
  isVendor: boolean;
  registerVendor: (data: Omit<Vendor, "id" | "verified" | "created_at">) => Promise<{ error?: string }>;
  addProduct: (data: Omit<VendorProduct, "id" | "vendor_id" | "created_at">) => Promise<{ error?: string }>;
  updateProduct: (id: string, data: Partial<VendorProduct>) => Promise<void>;
  deleteProduct: (id: string) => Promise<void>;
  updateOrderStatus: (orderId: string, status: Order["status"]) => Promise<void>;
  refreshOrders: () => Promise<void>;
  logout: () => void;
}

const VendorContext = createContext<VendorContextType | undefined>(undefined);

export function VendorProvider({ children }: { children: React.ReactNode }) {
  const [vendor, setVendor] = useState<Vendor | null>(null);
  const [products, setProducts] = useState<VendorProduct[]>([]);
  const [orders, setOrders] = useState<Order[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    loadData<Vendor | null>("nexskin_vendor", null).then(async (v) => {
      if (v?.id) {
        setVendor(v);
        await loadProducts(v.id);
        await loadOrders(v.id);
      }
      setIsLoading(false);
    });
  }, []);

  const loadProducts = async (vendorId: string) => {
    const { data } = await supabase
      .from("nexskin_vendor_products")
      .select("*")
      .eq("vendor_id", vendorId)
      .order("created_at", { ascending: false });
    if (data) setProducts(data);
  };

  const loadOrders = async (vendorId: string) => {
    const { data } = await supabase
      .from("nexskin_orders")
      .select("*, product:nexskin_vendor_products(*)")
      .eq("vendor_id", vendorId)
      .order("created_at", { ascending: false });
    if (data) setOrders(data);
  };

  const registerVendor = async (data: Omit<Vendor, "id" | "verified" | "created_at">) => {
    const { data: created, error } = await supabase
      .from("nexskin_vendors")
      .insert({ ...data, verified: false })
      .select()
      .single();
    if (error) return { error: error.message };
    setVendor(created);
    await saveData("nexskin_vendor", created);
    return {};
  };

  const addProduct = async (data: Omit<VendorProduct, "id" | "vendor_id" | "created_at">) => {
    if (!vendor) return { error: "Not logged in" };
    const { data: created, error } = await supabase
      .from("nexskin_vendor_products")
      .insert({ ...data, vendor_id: vendor.id })
      .select()
      .single();
    if (error) return { error: error.message };
    setProducts((prev) => [created, ...prev]);
    return {};
  };

  const updateProduct = async (id: string, data: Partial<VendorProduct>) => {
    await supabase.from("nexskin_vendor_products").update(data).eq("id", id);
    setProducts((prev) => prev.map((p) => (p.id === id ? { ...p, ...data } : p)));
  };

  const deleteProduct = async (id: string) => {
    await supabase.from("nexskin_vendor_products").delete().eq("id", id);
    setProducts((prev) => prev.filter((p) => p.id !== id));
  };

  const updateOrderStatus = async (orderId: string, status: Order["status"]) => {
    await supabase.from("nexskin_orders").update({ status }).eq("id", orderId);
    setOrders((prev) => prev.map((o) => (o.id === orderId ? { ...o, status } : o)));
  };

  const refreshOrders = async () => {
    if (vendor) await loadOrders(vendor.id);
  };

  const logout = () => {
    setVendor(null);
    setProducts([]);
    setOrders([]);
    saveData("nexskin_vendor", null);
  };

  return (
    <VendorContext.Provider value={{
      vendor, products, orders, isLoading,
      isVendor: !!vendor,
      registerVendor, addProduct, updateProduct, deleteProduct,
      updateOrderStatus, refreshOrders, logout,
    }}>
      {children}
    </VendorContext.Provider>
  );
}

export function useVendor() {
  const ctx = useContext(VendorContext);
  if (!ctx) throw new Error("useVendor must be inside VendorProvider");
  return ctx;
}
