import { createClient } from "@supabase/supabase-js";

const SUPABASE_URL = "https://xotljyulcdoobqslclax.supabase.co";
const SUPABASE_ANON_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InhvdGxqeXVsY2Rvb2Jxc2xjbGF4Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzM4NjA5NzksImV4cCI6MjA4OTQzNjk3OX0.oNzCwvTJEDQNj8Qfjpp0ydvySOwr3UXSJjeenBGHahY";

export const supabase = createClient(SUPABASE_URL, SUPABASE_ANON_KEY);

export type Vendor = {
  id: string;
  store_name: string;
  owner_name: string;
  email: string;
  phone: string;
  whatsapp: string;
  instagram?: string;
  tiktok?: string;
  location: string;
  category: string;
  description: string;
  logo_emoji: string;
  verified: boolean;
  created_at: string;
};

export type VendorProduct = {
  id: string;
  vendor_id: string;
  name: string;
  brand: string;
  price: number;
  description: string;
  category: string;
  skin_types: string[];
  concerns: string[];
  emoji: string;
  in_stock: boolean;
  created_at: string;
};

export type Order = {
  id: string;
  vendor_id: string;
  product_id: string;
  customer_name: string;
  customer_phone: string;
  customer_address: string;
  quantity: number;
  total_price: number;
  status: "pending" | "confirmed" | "shipped" | "delivered" | "cancelled";
  notes?: string;
  created_at: string;
  product?: VendorProduct;
};
