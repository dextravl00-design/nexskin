import React, { createContext, useContext, useEffect, useState } from "react";
import { Appearance, useColorScheme as useSystemScheme } from "react-native";
import { Colors, ColorScheme } from "./theme";

interface ThemeContextValue {
  colorScheme: ColorScheme;
  colors: typeof Colors.light;
  setColorScheme: (s: ColorScheme) => void;
  toggle: () => void;
}

const ThemeContext = createContext<ThemeContextValue | null>(null);

export function ThemeProvider({ children }: { children: React.ReactNode }) {
  const system = useSystemScheme() ?? "light";
  const [colorScheme, setScheme] = useState<ColorScheme>(system);

  const setColorScheme = (s: ColorScheme) => {
    setScheme(s);
    Appearance.setColorScheme?.(s);
    if (typeof document !== "undefined") {
      document.documentElement.classList.toggle("dark", s === "dark");
    }
  };

  const toggle = () => setColorScheme(colorScheme === "light" ? "dark" : "light");

  useEffect(() => {
    if (typeof document !== "undefined") {
      document.documentElement.classList.toggle("dark", colorScheme === "dark");
    }
  }, [colorScheme]);

  return (
    <ThemeContext.Provider value={{ colorScheme, colors: Colors[colorScheme], setColorScheme, toggle }}>
      {children}
    </ThemeContext.Provider>
  );
}

export function useTheme() {
  const ctx = useContext(ThemeContext);
  if (!ctx) throw new Error("useTheme must be inside ThemeProvider");
  return ctx;
}
