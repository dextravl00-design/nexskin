# NexSkin Vendor — Supabase Setup

Run these SQL statements in your Supabase SQL Editor at:
https://supabase.com/dashboard/project/xotljyulcdoobqslclax/sql

---

## Step 1 — Create Tables

```sql
-- Vendors table
create table if not exists nexskin_vendors (
  id uuid default gen_random_uuid() primary key,
  store_name text not null,
  owner_name text not null,
  email text not null,
  phone text not null,
  whatsapp text not null,
  instagram text,
  tiktok text,
  location text not null,
  category text not null,
  description text default '',
  logo_emoji text default '🌿',
  verified boolean default false,
  created_at timestamptz default now()
);

-- Vendor products table
create table if not exists nexskin_vendor_products (
  id uuid default gen_random_uuid() primary key,
  vendor_id uuid references nexskin_vendors(id) on delete cascade,
  name text not null,
  brand text default '',
  price numeric not null,
  description text default '',
  category text not null,
  skin_types text[] default '{}',
  concerns text[] default '{}',
  emoji text default '🧴',
  in_stock boolean default true,
  created_at timestamptz default now()
);

-- Orders table
create table if not exists nexskin_orders (
  id uuid default gen_random_uuid() primary key,
  vendor_id uuid references nexskin_vendors(id) on delete cascade,
  product_id uuid references nexskin_vendor_products(id) on delete set null,
  customer_name text not null,
  customer_phone text not null,
  customer_address text not null,
  quantity integer default 1,
  total_price numeric not null,
  status text default 'pending' check (status in ('pending','confirmed','shipped','delivered','cancelled')),
  notes text,
  created_at timestamptz default now()
);
```

## Step 2 — Enable Row Level Security (RLS)

```sql
alter table nexskin_vendors enable row level security;
alter table nexskin_vendor_products enable row level security;
alter table nexskin_orders enable row level security;

-- Allow public read and insert (for MVP — no auth)
create policy "Public read vendors" on nexskin_vendors for select using (true);
create policy "Public insert vendors" on nexskin_vendors for insert with check (true);
create policy "Public update vendors" on nexskin_vendors for update using (true);

create policy "Public read products" on nexskin_vendor_products for select using (true);
create policy "Public insert products" on nexskin_vendor_products for insert with check (true);
create policy "Public update products" on nexskin_vendor_products for update using (true);
create policy "Public delete products" on nexskin_vendor_products for delete using (true);

create policy "Public read orders" on nexskin_orders for select using (true);
create policy "Public insert orders" on nexskin_orders for insert with check (true);
create policy "Public update orders" on nexskin_orders for update using (true);
```

---

That's it! Your vendor system is ready.
